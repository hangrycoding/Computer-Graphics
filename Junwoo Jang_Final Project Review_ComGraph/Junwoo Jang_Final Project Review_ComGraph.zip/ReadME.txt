
1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./JJW_final.exe" to execute the program.


	This Program displays a beautiful neighborhood that has
	houses, a building, a tennis court, a swimming pool, a powerranger playing
	beer pong, etc.
	
	*******Hot Keys*******
	ESC: Exit Program
	0: Original(Reset) view with original angle

	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles
	d/D: The main door(/gate) open & close