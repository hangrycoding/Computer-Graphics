1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./hw2.exe" to execute the program to
view the Lorenz Attractor.



This Program displays the lorenz attractor in different angles, perspectives, 
	closeness, and dimensions (in x-axis, y-axis, and z-axis).

By using the hot keys below, you can enjoy viewing the Lorenz Attractor!
	*******Hot Keys*******
	↑↓→←: View with different angles
	0: Original(Reset) view with original angle
	PageDown/PageUp: Zoom in/out
	ESC: Exit Program
	+: x dimension increase
	-: x dimension decrease
	*: y dimension increase
	/: y dimension decrease
	]: z dimension increase
	[: z dimension decrease