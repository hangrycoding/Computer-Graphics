
/*
	Junwoo Jang - CS 5229 - HW5
	Got few ideas from examples(13), Youtube, and my Brain
	
	This Program displays Wonderful Twin Red Power Rangers with a cute mint bazooka gun on his head	and a beautiful Rainbow.
	And You can view this with two different views: Orthogonal, Perpective
	And you can enjoy it with lights.
	
	*******Hot Keys*******
	ESC: Exit Program
	0: Original(Reset) view with original angle
	l: Toggle the lighting
	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles


	Q/q: Increase/Decrease the ambient light
	W/w: Increase/Decrease the diffuse light
	E/e: Increase/Decrease the emitted light
	R/r: Increase/Decrease the specular light
	T/t: Increase/Decrease the shininess


	F1: Toggle the smooth/flat shading
	F2: Toggle the local viewer mode
	F3: Toggle the light distance (1/5) 
	F8: Change the ball increment
	F9: Invert thebottom normal


	*,/: Controlling the Light Distance:Increase, Decrease   
	],[: Rise,Lower the light 
	+/-: Change field of view


	m/M: Switch View Modes(→Orthogonal View→Perpective View→)
	p/P: Hide PowerRangers & Show PowerRangersxes
	b/B: Hide Rainbow & Show RainBow 
 

	x/X: Hide Axes & Show Axes
	z/Z: Toggle the light movement

*/


//Header files
#include <math.h> //standard library  for basic mathematical operations
#include <stdlib.h> //handles memory allocation, process control, conversions and others
#include <stdarg.h> //for  indefinite number of argument
#include <stdio.h> //for input and output
#include <string.h> 
//for OpenGL 
#ifdef USEGLEW 
#include <GL/glew.h> 
#endif 
#define GL_GLEXT_PROTOTYPES 
#ifdef __APPLE__ 
#include <GLUT/glut.h> 
#else 
#include <GL/glut.h> 
#endif 


int circangle=0; //Azimuth when viewing angle         
int elevat=0; //Elevation when viewing angle   
double ROT=0; //For the Rotation

int chook=1; //Axes       
int YOpower_ranger = 1; //Variable for showingnhiding PowerRangers 
int RainBow = 1; //Variable for showingnhiding RainBow


int orth_per_fp_view=1; //Variable for view mode: orthogonal, perspective
int perspective_view=55; // For perspective view

int MovOfLight=1; //For the movement of the light
int LIGHT=1;      // for the light
int UV=1; //for the unit value
double DofLight= 5;  // For the distance of the light
double widnheight_ratio=1;      
double worldsize=3.0;     


int BallInc=10;  
int sm_flat_shading=1;  
int LocalVIEWER_M=0;  
int EMIS=0; 
int AMB=30; 
int diffuse=100;  
int SPEC=0;  
int SHINE_L=0;  
float SHIN_Y=1;  
float Light_elevat=0;  

#define Cos(x) (cos((x)*3.1415927/180))
#define Sin(x) (sin((x)*3.1415927/180))

#define LEN 8192  

//To print out
void characprint(const char* format , ...)
{
   char    chprint[LEN]; //Set length(8192) for the characters
   char*   ch=chprint;
   va_list args;
   va_start(args,format);
   vsnprintf(chprint,LEN,format,args);
   va_end(args);
   
   //  Display chracters
   while (*ch)
      glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*ch++);
}


// To use GLUT, this function is necessary
void Fatal4gl(const char* format , ...)
{
   va_list args;
   va_start(args,format);
   vfprintf(stderr,format,args);
   va_end(args);
   exit(1);
}

//For Projection Views
void PROJECTION(double perspective_view,double widnheight_ratio,double worldsize) 
{ 
  
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity(); 


   if (perspective_view) 
   {
      gluPerspective(perspective_view,widnheight_ratio,worldsize/16,16*worldsize); 
   }
	//For Orthogonal view mode
   else 
   {
      glOrtho(-widnheight_ratio*worldsize,widnheight_ratio*worldsize,-worldsize,+worldsize,-worldsize,+worldsize); 
   }
  
   glMatrixMode(GL_MODELVIEW); 
   glLoadIdentity(); 
}


//Good to include to check error
void CheckError(const char* where) 
{ 
   int err = glGetError(); 
   if (err) fprintf(stderr,"ERROR: %s [%s]\n",gluErrorString(err),where); 
} 


static void Vertex(double circangle,double elevat)
{
   double vertex_x = Sin(circangle)*Cos(elevat); 
   double vertex_y = Cos(circangle)*Cos(elevat); 
   double vertex_z = Sin(elevat); 
   
   glNormal3d(vertex_x,vertex_y,vertex_z); 
   glColor3f(Cos(circangle)*Cos(circangle), Sin(elevat)*Sin(elevat), Sin(circangle)*Sin(circangle)); //For the beautiful rainbow ball
   glVertex3d(vertex_x,vertex_y,vertex_z); 
   
}





//Drawing a Cube (to draw PowerRangers) 
//lr:left,right(x), ud:updown(y), fb:frontback(z), size: for dimension, col:for color, rot:for rotation
static void NEMO(double NEMO_lr,double NEMO_ud,double NEMO_fb, 
                 double NEMO_size_lr,double NEMO_size_ud,double NEMO_size_fb,
                 double NEMO_col_1, double NEMO_col_2, double NEMO_col_3,
                 double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3)
{
   
   glPushMatrix();
   glTranslated(NEMO_lr,NEMO_ud,NEMO_fb);
   glRotated(NEMO_rot_1,1,0,0);
   glRotated(NEMO_rot_1,0,1,0);
   glRotated(NEMO_rot_3,0,0,1);
   glScaled(NEMO_size_lr,NEMO_size_ud,NEMO_size_fb);
  
   glBegin(GL_QUADS);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Front
   glNormal3f( 0, 0, 1); 
   glVertex3f(-1,-1, 1);
   glVertex3f(+1,-1, 1);
   glVertex3f(+1,+1, 1);
   glVertex3f(-1,+1, 1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Back
   glNormal3f( 0, 0, -1); 
   glVertex3f(+1,-1,-1);
   glVertex3f(-1,-1,-1);
   glVertex3f(-1,+1,-1);
   glVertex3f(+1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Right
   glNormal3f( 1, 0, 0); 
   glVertex3f(+1,-1,+1);
   glVertex3f(+1,-1,-1);
   glVertex3f(+1,+1,-1);
   glVertex3f(+1,+1,+1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Left
   glNormal3f(-1, 0, 0); 
   glVertex3f(-1,-1,-1);
   glVertex3f(-1,-1,+1);
   glVertex3f(-1,+1,+1);
   glVertex3f(-1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Top
   glNormal3f( 0, 1, 0); 
   glVertex3f(-1,+1,+1);
   glVertex3f(+1,+1,+1);
   glVertex3f(+1,+1,-1);
   glVertex3f(-1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Bottom
   glNormal3f( 0, -1, 0); 
   glVertex3f(-1,-1,-1);
   glVertex3f(+1,-1,-1);
   glVertex3f(+1,-1,+1);
   glVertex3f(-1,-1,+1);
   
   glEnd();
   glPopMatrix();
}





//Drawing a Cylinder (to draw the Beautiful RainBow)
//rad: radius, H:height, ang:angle
static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, double circangle, double circrad, double circH, double circ_col_1, double circ_col_2, double circ_col_3)
{
    double BONG_ang = 0.0;
    double BONG_s = 0.1;
    
    
    glPushMatrix();
    
    glRotatef(circangle, 0, 1, 0); //To Rotate
    glRotatef(circangle, 1, 0, 0); //To Rotate
   
    glTranslated(BONG_lr,BONG_ud,BONG_fb);
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_QUAD_STRIP);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , circH);
        glVertex3f(BONG_lr, BONG_ud , 0.0);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glVertex3f(circrad, 0.0, 0.0);
    glEnd();
    
    // For the Lid(top circle)
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , circH);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glEnd();
    
    // For the bottom circle
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , 0);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glEnd();
  
    glPopMatrix();
    
}





static void PowerRanger(double PR_lr, double PR_ud, double PR_fb, double PR_ds, double PR_rot_K, double PR_rot_O, double PR_rot_R)
{
    
    glPushMatrix();

    glTranslated(PR_lr, PR_ud, PR_fb);
    glRotated(PR_rot_K, 1, 0, 0);
    glRotated(PR_rot_O, 0, 1, 0);
    glRotated(PR_rot_R, 0, 0, 1);
    glScaled(PR_ds, PR_ds, PR_ds);

    NEMO(0, 0.6, 0, 0.4, 0.3, 0.4, 1, 1, 1, 0, 0, 0);  // The White Face
		  
    NEMO(0, 1.1, -0.03, 0.47, 0.13, 0.47, 0, 0.1, 1, 0, 0, 0);   // The Blue Sunglasses
    NEMO(0, 1.3, -0.06, 0.36, 0.1, 0.36, 0.8, 0.1, 1, 0, 0, 0); 
    NEMO(0, 1.22, 0.4, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0);
    NEMO(0, 1.32, -0.46, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0, 1.16, -0.56, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0.5, 0.6, 0, 0.07, 0.45, 0.45, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0.6, 0.6, -0.1, 0.07, 0.2, 0.2, 0.9, 0, 0, 0, 0, 0);	
    NEMO(-0.5, 0.6, 0, 0.07, 0.45, 0.45, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(-0.6, 0.6, -0.1, 0.07, 0.2, 0.2, 0.9, 0, 0, 0, 0, 0);  
    NEMO(0, 0.6, -0.5, 0.45, 0.45, 0.07, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0, 0.6, -0.6, 0.4, 0.4, 0.07, 0.9, 0, 0, 0, 0, 0);  
    NEMO(0, 0.6, -0.7, 0.3, 0.3, 0.07, 0.9, 0, 0, 0, 0, 0); 
	

	BONG(0, 1.5, -0.4, -0.58, 0.2, 1.3, 0, 1, 0.7); //For the bazooka gun
	

    NEMO(0.2, 0.62, 0.45, 0.2, 0.11, 0.01, 0, 0, 0, 0, 0, 0); // Left Eye(from the PowerRanger Side)	  
    NEMO(-0.2, 0.62, 0.45, 0.2, 0.11, 0.01, 0, 0, 0, 0, 0, 0);  // Right Eye(from the PowerRanger Side)

    NEMO(0, 0.4, 0.48, 0.1, 0.05, 0.01, 0.8, 0.8, 0.8, 0, 0, 0); // Mask
    NEMO(0, 0.2, 0, 0.9, 0.09, 0.1, 0.9, 0.5, 0.9, 0, 0, 0);  // Pink Shoulder Pad

    NEMO(0, 0, 0, 0.25, 0.2, 0.15, 0.9, 0, 0, 0, 0, 0); //BODY	 
    NEMO(0, -0.27, 0, 0.19, 0.07, 0.1, 0.9, 0, 0, 0, 0, 0); 

    NEMO(0.54, 0.02, 0, 0.3, 0.08, 0.08, 0.9, 0, 0, 0, 0, 0);  //Left Arm(RED) 
    NEMO(0.85, 0.02, 0, 0.1, 0.15, 0.15, 1, 1, 1, 0, 0, 0);  //Left Arm-Hand(White)
    NEMO(1.36, 0.3, 0, 0.4, 0.1, 0.15, 0.4, 0.4, 0.5, 0, 0, 0);  // Laser Gun
    NEMO(1.8, 0.3, 0, 0.2, 0.05, 0.15, 1, 1, 1, 0, 0, 0);  // White Silencer
	NEMO(2.2, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim1
	NEMO(2.4, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim2	
	NEMO(2.6, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim3
    NEMO(1.0, 0.05, 0, 0.1, 0.15, 0.15, 0.4, 0.4, 0.5, 0, 0, 0);  //Gun Handle

	
	NEMO(-0.32, 0.02, 0, 0.3, 0.08, 0.08, 0.9, 0, 0, 0, 0, 0);  //Right Arm(RED)	
    NEMO(-0.63, 0.02, 0, 0.1, 0.15, 0.15, 1, 1, 1, 0, 0, 0);  //Right Arm-Hand(White)

		 
    NEMO(0, -0.4, 0, 0.2, 0.08, 0.12, 1, 1, 1, 0, 0, 0); //Belt(White)
    NEMO(0, -0.4, 0, 0.1, 0.05, 0.13, 0.9, 1, 0, 0, 0, 0); //Belt Label(Yellow)  
		  
    NEMO(0.15, -0.6, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25); //Left Leg 
    NEMO(0.25, -0.8, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25);  
    NEMO(0.3, -0.9, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25); 	 
    NEMO(0.41, -1.1, 0, 0.25, 0.12, 0.2, 0.9, 0, 0, 0, 0, 25); //Shoe
		    
    NEMO(-0.15, -0.6, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); //Right Leg  
    NEMO(-0.25, -0.8, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); 
    NEMO(-0.3, -0.9, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); 
    NEMO(-0.41, -1.1, 0, 0.25, 0.12, 0.2, 0.9, 0, 0, 0, 0, -25); //Shoe 
		 
    glPopMatrix();
}



static void ball(double BALL_x,double BALL_y,double BALL_z,double BALL_r) 
{
   int BALL_circangle,BALL_elevat; 
   float BALL_norang[] = {1.0,1.0,0.0,1.0}; 
   float BALL_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   
   glPushMatrix(); 
   glTranslated(BALL_x,BALL_y,BALL_z); 
   glScaled(BALL_r,BALL_r,BALL_r); 
   
   glColor3f(1,1,1); // Ball color set up
   glMaterialf(GL_FRONT,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT,GL_SPECULAR,BALL_norang); 
   glMaterialfv(GL_FRONT,GL_EMISSION,BALL_emis); 



   for (BALL_elevat=-90;BALL_elevat<90;BALL_elevat+=BallInc) 
   {
      glBegin(GL_QUAD_STRIP); 
      for (BALL_circangle=0;BALL_circangle<=360;BALL_circangle+=2*BallInc) 
      {
         Vertex(BALL_circangle,BALL_elevat); 
         Vertex(BALL_circangle,BALL_elevat+BallInc); 
      } 
      glEnd(); 
   } 
   
   glPopMatrix(); 
} 



//For the scene(background)
void draw_scene()
{
   const double chook_len=1.5;  //Axes' Length
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   glEnable(GL_DEPTH_TEST);
   glLoadIdentity();
   
   //For the View modes
   if (orth_per_fp_view)
   {
	  double BIGeye_x = -2*worldsize*Sin(circangle)*Cos(elevat); 
      double BIGeye_y = +2*worldsize        *Sin(elevat); 
      double BIGeye_z = +2*worldsize*Cos(circangle)*Cos(elevat); 

      gluLookAt(BIGeye_x,BIGeye_y,BIGeye_z,0,0,0,0,Cos(elevat),0); 
   }
   else 
   { 
      glRotatef(elevat,1,0,0); 
      glRotatef(circangle,0,1,0); 
   } 
   
    glShadeModel(sm_flat_shading ? GL_SMOOTH : GL_FLAT); 
 
   if (LIGHT) 
   { 
        
        float LIGHT_amb[]   = {0.01*AMB ,0.01*AMB ,0.01*AMB ,1.0}; 
        float LIGHT_Diffuse[]   = {0.01*diffuse ,0.01*diffuse ,0.01*diffuse ,1.0}; 
        float LIGHT_SPEC[]  = {0.01*SPEC,0.01*SPEC,0.01*SPEC,1.0}; 
        float LIGHT_Pos[]  = {DofLight*Cos(ROT),Light_elevat,DofLight*Sin(ROT),1.0}; 
        
		glColor3f(1,1,1); 
        ball(LIGHT_Pos[0],LIGHT_Pos[1],LIGHT_Pos[2] , 0.1); 
        glEnable(GL_NORMALIZE); 
        glEnable(GL_LIGHTING); 
        glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,LocalVIEWER_M); 
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE); 
        glEnable(GL_COLOR_MATERIAL); 
        glEnable(GL_LIGHT0); 
        glLightfv(GL_LIGHT0,GL_AMBIENT ,LIGHT_amb); 
        glLightfv(GL_LIGHT0,GL_DIFFUSE ,LIGHT_Diffuse); 
        glLightfv(GL_LIGHT0,GL_SPECULAR,LIGHT_SPEC); 
        glLightfv(GL_LIGHT0,GL_POSITION,LIGHT_Pos); 
   }
   else  
   {
     glDisable(GL_LIGHTING);  
   }
   


//3D Objects
   if (YOpower_ranger) 
   { 
      PowerRanger(-2.3, 0.98, -0.5, 0.6, 0, 45, 0); //PowerRanger1
      PowerRanger(0.8, 1, -1.2, 0.6, 0, 0, 0); //PowerRanger2
   }

   if (RainBow)
   {
		BONG(0.7, -1.5, 0.2, 90, 0.1, 0.5, 0.4, 0, 0.5);
		BONG(0.7, -1, 0.2, 90, 0.1, 0.6, 0.4, 0.1, 0.9);
		BONG(0.7, -0.5, 0.2, 90, 0.1, 0.7, 0.4, 0.3, 1); 
		BONG(0.7, 0, 0.2, 90, 0.1, 0.9, 0.4, 1, 0); 
		BONG(0.7, 0.5, 0.2, 90, 0.1, 0.8, 1, 1, 0); 
		BONG(0.7, 1, 0.2, 90, 0.1, 0.7, 0.9, 0.5, 0);    
		BONG(0.7, 1.5, 0.2, 90, 0.1, 0.6, 0.9, 0, 0); 
   }
 
   glColor3f(1,1,1); //Axes

   if (chook)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(chook_len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,chook_len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,chook_len);
      glEnd();
      //For Axes
      glRasterPos3d(chook_len,0.0,0.0);
      characprint("X");
      glRasterPos3d(0.0,chook_len,0.0);
      characprint("Y");
      glRasterPos3d(0.0,0.0,chook_len);
      characprint("Z");
   }
   
   glWindowPos2i(5,5);
   characprint("Angle=%d,%d  Dim=%.1f FOV=%d Projection=%s Light=%s",circangle,elevat,worldsize,perspective_view,orth_per_fp_view?"Perpective":"Orthogonal",LIGHT?"On":"Off"); 

   if (LIGHT) 
   { 
      glWindowPos2i(5,45); 
      characprint("Model=%s LocalViewer=%s Distance=%d Elevation=%.1f",sm_flat_shading?"Smooth":"Flat",LocalVIEWER_M?"On":"Off",DofLight,Light_elevat); 
      glWindowPos2i(5,25); 
      characprint("Ambient=%d  Diffuse=%d Specular=%d Emission=%d Shininess=%.0f",AMB,diffuse,SPEC,EMIS,SHIN_Y); 
   } 
   
   CheckError("display"); 
   
   
   glFlush();
   glutSwapBuffers();
}

//Hotkeys for Arrows
void special_hotkey(int hotkey_press,int hotkey_x,int hotkey_y)
{
	
   if (hotkey_press == GLUT_KEY_RIGHT)
   {
      circangle += 5;
   }
   else if (hotkey_press == GLUT_KEY_LEFT)
   {
      circangle -= 5;
   }
   else if (hotkey_press == GLUT_KEY_UP)
   {
      elevat += 5;
   }
   else if (hotkey_press == GLUT_KEY_DOWN)
   {
      elevat -= 5;
   }
   else if (hotkey_press == GLUT_KEY_PAGE_DOWN)
   {
      worldsize += 0.1; 
   }
   else if (hotkey_press == GLUT_KEY_PAGE_UP && worldsize>1)
   {
      worldsize -= 0.1; 
   }
   else if (hotkey_press == GLUT_KEY_F1) 
   {
      sm_flat_shading = 1-sm_flat_shading; 
   }
   else if (hotkey_press == GLUT_KEY_F2) 
   {
      LocalVIEWER_M = 1-LocalVIEWER_M; 
   }
   else if (hotkey_press == GLUT_KEY_F3) 
   {
      DofLight = (DofLight==1) ? 5 : 1; 
   }
   else if (hotkey_press == GLUT_KEY_F8) 
   {
      BallInc = (BallInc==10)?3:10; 
   }
   else if (hotkey_press == GLUT_KEY_F9) 
   {
      UV = -UV; 
   }
  
   circangle %= 360; 
   elevat %= 360; 
   glutPostRedisplay();
}

void idle()
{

   double idle_time = glutGet(GLUT_ELAPSED_TIME)/1000.0; 
   ROT = fmod(90*idle_time,360); 
   glutPostRedisplay();
}

void hotkey_press(unsigned char ch,int hk_press_x,int hk_press_y)
{
   if (ch == 27)
   {
      exit(0);
   }
   else if (ch == '0')
   {
      circangle = elevat = 0;
   }
   else if (ch == 'x' || ch == 'X') 
   {
	  chook = 1-chook; 
   }
   else if (ch == 'l' || ch == 'L') 
   {
      LIGHT = 1-LIGHT; 
   }
   else if (ch == 'm' || ch == 'M')
   {
      orth_per_fp_view = 1-orth_per_fp_view;
   }
   else if (ch == 'z' || ch == 'Z') 
   {
      MovOfLight = 1-MovOfLight; 
   }
   else if (ch == '<') 
   {
      ROT += 1;
   }
   else if (ch == '>') 
   {
      ROT -= 1;
   }
   else if (ch == '-' && ch>1) 
   {
	  perspective_view--; 
   }
   else if (ch == '+' && ch<179) 
   {
	  perspective_view++; 
   }
   
   else if (ch=='[') 
   {
      Light_elevat -= 0.1; 
   }
   else if (ch==']') 
   {
      Light_elevat += 0.1;
   }	  
   else if (ch == '/') 
   {
      DofLight -= 0.1; 
   }
   else if (ch == '*') 
   {
      DofLight += 0.1; 
   }
   else if (ch == 'p' || ch == 'P')
   {
      YOpower_ranger = 1-YOpower_ranger;
   }
   else if (ch == 'b' || ch == 'B')
   {
      RainBow = 1-RainBow;
   }
   
   else if (ch=='q' && AMB>0) 
   {
      AMB -= 5;
   }
   else if (ch=='Q' && AMB<100) 
   {
      AMB += 5; 
   }
   else if (ch=='w' && diffuse>0) 
   {
      diffuse -= 5;
   }
   else if (ch=='W' && diffuse<100) 
   {
      diffuse += 5; 
   }
   else if (ch=='r' && SPEC>0) 
   {
      SPEC -= 5; 
   }
   else if (ch=='R' && SPEC<100) 
   {
      SPEC += 5; 
   }
   else if (ch=='e' && EMIS>0) 
   {
      EMIS -= 5; 
   }
   else if (ch=='E' && EMIS<100) 
   {
      EMIS += 5; 
   }
   else if (ch=='t' && SHINE_L>-1) 
   {
      SHINE_L -= 1; 
   }
   else if (ch=='T' && SHINE_L<7) 
   {
      SHINE_L += 1; 
   }

   SHIN_Y = SHINE_L<0 ? 0 : pow(2.0,SHINE_L); 
   PROJECTION(orth_per_fp_view?perspective_view:0,widnheight_ratio,worldsize); 
   glutIdleFunc(MovOfLight?idle:NULL); 
   glutPostRedisplay();
}

//Reshape
void shapeRedraw(int width,int height)
{
   const double worldsize=2.5;
   widnheight_ratio = (height>0) ? (double)width/height : 1; 

   double widnheight = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-widnheight*worldsize,+widnheight*worldsize, -worldsize,+worldsize, -worldsize,+worldsize); 
   
   
   glMatrixMode(GL_MODELVIEW);
   PROJECTION(orth_per_fp_view?perspective_view:0,widnheight_ratio,worldsize); 
   glLoadIdentity();
}




// Tell GLUT what to do
int main(int argument1,char* argument2[])
{
   glutInit(&argument1,argument2);
   glutInitWindowSize(1060,850);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutCreateWindow("Junwoo Jang - CSCI5229 - HW5, PowerRangers with a RainBow(Light and Two view modes)");
   glutIdleFunc(idle);
   #ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal4gl("Error initializing GLEW\n");
   #endif
   glutDisplayFunc(draw_scene);
   glutReshapeFunc(shapeRedraw);
   glutSpecialFunc(special_hotkey);
   glutKeyboardFunc(hotkey_press);
   
   CheckError("init");   
   glutMainLoop();
   return 0;
}
