
1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./hw5.exe" to execute the program.




This Program displays Wonderful Twin Red Power Rangers with a cute mint bazooka gun on his head	and a beautiful Rainbow.
And You can view this with two different views: Orthogonal, Perpective
And you can enjoy it with lights.
	
	*******Hot Keys*******
	ESC: Exit Program
	0: Original(Reset) view with original angle
	l: Toggle the lighting
	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles


	Q/q: Increase/Decrease the ambient light
	W/w: Increase/Decrease the diffuse light
	E/e: Increase/Decrease the emitted light
	R/r: Increase/Decrease the specular light
	T/t: Increase/Decrease the shininess


	F1: Toggle the smooth/flat shading
	F2: Toggle the local viewer mode
	F3: Toggle the light distance (1/5) 
	F8: Change the ball increment
	F9: Invert thebottom normal


	*,/: Controlling the Light Distance:Increase, Decrease   
	],[: Rise,Lower the light 
	+/-: Change field of view


	m/M: Switch View Modes(→Orthogonal View→Perpective View→)
	p/P: Hide PowerRangers & Show PowerRangersxes
	b/B: Hide Rainbow & Show RainBow 
 

	x/X: Hide Axes & Show Axes
	z/Z: Toggle the light movement