
1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./hw4.exe" to execute the program to
view the Lorenz Attractor.


This Program displays Wonderful Twin Red Power Rangers and a beautiful Rainbow
And You can view this with three different views: Orthogonal, Perpective, First Person.
	


*******Hot Keys*******
	
	m/M: Switch View Modes(→Orthogonal View→Perpective View→FirstPerson View→)
	ESC: Exit Program
	x/X: Hide Axes & Show Axes
	p/P: Hide PowerRangers & Show PowerRangersxes
	r/R: Hide Rainbow & Show RainBow
	
	
	When it is Orthogonal View Only:
	
	w,W/s,S: View UP/View Down
	a,A/d,D: View Left/View Right
	],[: Zoom in & out
	0: Original(Reset) view with original angle
	
	
	When it is Perpective View Only:
	
	w,W/s,S: View UP/ View Down
	a,A/d,D: View Left/View Right
	+/-: Change field of view
	],[: Zoom in & out
	0: Original(Reset) view with original angle

	When it is First Person View Only:
	
	↑↓→←: Move forward, backward, Look at Right, Look at Left 
	*,/: Increase Horizontal View point,Decrease Horizontal View point
	+/-: Change field of view
	0: Original(Reset) view with original angle