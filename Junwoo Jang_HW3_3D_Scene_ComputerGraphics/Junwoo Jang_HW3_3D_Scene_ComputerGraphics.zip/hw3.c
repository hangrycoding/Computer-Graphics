
/*
	Junwoo Jang - CS 5229 - HW3
	Got few ideas from example 8, Youtube, and my Brain
	
	This Program displays Wonderful Twin Red Power Rangers and a beautiful Rainbow
	
	*******Hot Keys*******
	↑↓→←: View with different angles
	0: Original(Reset) view with original angle
	ESC: Exit Program
	
	a/A: Hide Axes & Show Axes
    p/P: Hide PowerRangers & Show PowerRangers
	r/R: Hide Rainbow & Show RainBow
 
*/


//Header files
#include <math.h> //standard library  for basic mathematical operations
#include <stdlib.h> //handles memory allocation, process control, conversions and others
#include <stdarg.h> //for  indefinite number of argument
#include <stdio.h> //for input and output
#include <string.h> 
//for OpenGL 
#ifdef USEGLEW 
#include <GL/glew.h> 
#endif 
#define GL_GLEXT_PROTOTYPES 
#ifdef __APPLE__ 
#include <GLUT/glut.h> 
#else 
#include <GL/glut.h> 
#endif 

int circangle=0; //Azimuth when viewing angle         
int elevat=0; //Elevation when viewing angle         
int chook=1; // Axes       

int YOpower_ranger = 1; //Variable for showingnhiding PowerRangers 

int RainBow = 1; //Variable for showingnhiding RainBow



#define Cos(x) (cos((x)*3.1415927/180))
#define Sin(x) (sin((x)*3.1415927/180))


#define LEN 8192  

//To print out
void characprint(const char* format , ...)
{
   char    chprint[LEN]; //Set length(8192) for the characters
   char*   ch=chprint;
   va_list args;
   
   va_start(args,format);
   vsnprintf(chprint,LEN,format,args);
   va_end(args);
   
   //  Display chracters
   while (*ch)
      glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*ch++);
}


// To use GLUT, this function is necessary
void Fatal4gl(const char* format , ...)
{
   va_list args;
   va_start(args,format);
   vfprintf(stderr,format,args);
   va_end(args);
   exit(1);
}

//Drawing a Cube (to draw PowerRangers) 
//lr:left,right(x), ud:updown(y), fb:frontback(z), size: for dimension, col:for color, rot:for rotation
static void NEMO(double NEMO_lr,double NEMO_ud,double NEMO_fb, 
                 double NEMO_size_lr,double NEMO_size_ud,double NEMO_size_fb,
                 double NEMO_col_1, double NEMO_col_2, double NEMO_col_3,
                 double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3)
{
   
   glPushMatrix();
   glTranslated(NEMO_lr,NEMO_ud,NEMO_fb);
   glRotated(NEMO_rot_1,1,0,0);
   glRotated(NEMO_rot_1,0,1,0);
   glRotated(NEMO_rot_3,0,0,1);
   glScaled(NEMO_size_lr,NEMO_size_ud,NEMO_size_fb);
  
 
   glBegin(GL_QUADS);
   
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Front
   glVertex3f(-1,-1, 1);
   glVertex3f(+1,-1, 1);
   glVertex3f(+1,+1, 1);
   glVertex3f(-1,+1, 1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Back
   glVertex3f(+1,-1,-1);
   glVertex3f(-1,-1,-1);
   glVertex3f(-1,+1,-1);
   glVertex3f(+1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Right
   glVertex3f(+1,-1,+1);
   glVertex3f(+1,-1,-1);
   glVertex3f(+1,+1,-1);
   glVertex3f(+1,+1,+1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Left
   glVertex3f(-1,-1,-1);
   glVertex3f(-1,-1,+1);
   glVertex3f(-1,+1,+1);
   glVertex3f(-1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Top
   glVertex3f(-1,+1,+1);
   glVertex3f(+1,+1,+1);
   glVertex3f(+1,+1,-1);
   glVertex3f(-1,+1,-1);
   
   glColor3d(NEMO_col_1, NEMO_col_2, NEMO_col_3); //  Bottom
   glVertex3f(-1,-1,-1);
   glVertex3f(+1,-1,-1);
   glVertex3f(+1,-1,+1);
   glVertex3f(-1,-1,+1);
   
   glEnd();
   glPopMatrix();
}


//Drawing a Cylinder (to draw the Beautiful RainBow)
//rad: radius, H:height, ang:angle
static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, double circangle, double circrad, double circH, double circ_col_1, double circ_col_2, double circ_col_3)
{
    double BONG_ang = 0.0;
    double BONG_s = 0.1;
    
    
    glPushMatrix();
    
    glRotatef(circangle, 0, 1, 0); //To Rotate
    glRotatef(circangle, 1, 0, 0); //To Rotate
   
    glTranslated(BONG_lr,BONG_ud,BONG_fb);
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_QUAD_STRIP);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , circH);
        glVertex3f(BONG_lr, BONG_ud , 0.0);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glVertex3f(circrad, 0.0, 0.0);
    glEnd();
    
    // For the Lid(top circle)
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , circH);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glEnd();
    
    // For the bottom circle
    glColor3f(circ_col_1,circ_col_2,circ_col_3);
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
        glVertex3f(BONG_lr, BONG_ud , 0);
        BONG_ang = BONG_ang + BONG_s;
    }
    glVertex3f(circrad, 0.0, circH);
    glEnd();
  
    glPopMatrix();
    
}





static void PowerRanger(double PR_lr, double PR_ud, double PR_fb, double PR_ds, double PR_rot_K, double PR_rot_O, double PR_rot_R)
{
    
    glPushMatrix();

    glTranslated(PR_lr, PR_ud, PR_fb);
    glRotated(PR_rot_K, 1, 0, 0);
    glRotated(PR_rot_O, 0, 1, 0);
    glRotated(PR_rot_R, 0, 0, 1);
    glScaled(PR_ds, PR_ds, PR_ds);

    NEMO(0, 0.6, 0, 0.4, 0.3, 0.4, 1, 1, 1, 0, 0, 0);  // The White Face
		  
    NEMO(0, 1.1, -0.03, 0.47, 0.13, 0.47, 0, 0.1, 1, 0, 0, 0);   // The Blue Sunglasses
    NEMO(0, 1.3, -0.06, 0.36, 0.1, 0.36, 0.8, 0.1, 1, 0, 0, 0); 
    NEMO(0, 1.22, 0.4, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0);
    NEMO(0, 1.32, -0.46, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0, 1.16, -0.56, 0.1, 0.1, 0.1, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0.5, 0.6, 0, 0.07, 0.45, 0.45, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0.6, 0.6, -0.1, 0.07, 0.2, 0.2, 0.9, 0, 0, 0, 0, 0);	
    NEMO(-0.5, 0.6, 0, 0.07, 0.45, 0.45, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(-0.6, 0.6, -0.1, 0.07, 0.2, 0.2, 0.9, 0, 0, 0, 0, 0);  
    NEMO(0, 0.6, -0.5, 0.45, 0.45, 0.07, 0.9, 0, 0, 0, 0, 0); 	 
    NEMO(0, 0.6, -0.6, 0.4, 0.4, 0.07, 0.9, 0, 0, 0, 0, 0);  
    NEMO(0, 0.6, -0.7, 0.3, 0.3, 0.07, 0.9, 0, 0, 0, 0, 0); 

    NEMO(0.2, 0.62, 0.45, 0.2, 0.11, 0.01, 0, 0, 0, 0, 0, 0); // Left Eye(from the PowerRanger Side)	  
    NEMO(-0.2, 0.62, 0.45, 0.2, 0.11, 0.01, 0, 0, 0, 0, 0, 0);  // Right Eye(from the PowerRanger Side)

    NEMO(0, 0.4, 0.48, 0.1, 0.05, 0.01, 0.8, 0.8, 0.8, 0, 0, 0); // Mask
    NEMO(0, 0.2, 0, 0.9, 0.09, 0.1, 0.9, 0.5, 0.9, 0, 0, 0);  // Pink Shoulder Pad

    NEMO(0, 0, 0, 0.25, 0.2, 0.15, 0.9, 0, 0, 0, 0, 0); //BODY	 
    NEMO(0, -0.27, 0, 0.19, 0.07, 0.1, 0.9, 0, 0, 0, 0, 0); 

    NEMO(0.54, 0.02, 0, 0.3, 0.08, 0.08, 0.9, 0, 0, 0, 0, 0);  //Left Arm(RED) 
    NEMO(0.85, 0.02, 0, 0.1, 0.15, 0.15, 1, 1, 1, 0, 0, 0);  //Left Arm-Hand(White)
    NEMO(1.36, 0.3, 0, 0.4, 0.1, 0.15, 0.4, 0.4, 0.5, 0, 0, 0);  // Laser Gun
    NEMO(1.8, 0.3, 0, 0.2, 0.05, 0.15, 1, 1, 1, 0, 0, 0);  // White Silencer
	NEMO(2.2, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim1
	NEMO(2.4, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim2	
	NEMO(2.6, 0.3, 0, 0.04, 0.02, 0.15, 0, 1, 0.4, 0, 0, 0);  // The Laser Bim3
    NEMO(1.0, 0.05, 0, 0.1, 0.15, 0.15, 0.4, 0.4, 0.5, 0, 0, 0);  //Gun Handle
	NEMO(-0.32, 0.02, 0, 0.3, 0.08, 0.08, 0.9, 0, 0, 0, 0, 0);  //Right Arm(RED)	
    NEMO(-0.63, 0.02, 0, 0.1, 0.15, 0.15, 1, 1, 1, 0, 0, 0);  //Right Arm-Hand(White)
		 
    NEMO(0, -0.4, 0, 0.2, 0.08, 0.12, 1, 1, 1, 0, 0, 0); //Belt(White)
    NEMO(0, -0.4, 0, 0.1, 0.05, 0.13, 0.9, 1, 0, 0, 0, 0); //Belt Label(Yellow)  
		  
    NEMO(0.15, -0.6, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25); //Left Leg 
    NEMO(0.25, -0.8, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25);  
    NEMO(0.3, -0.9, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, 25); 	 
    NEMO(0.41, -1.1, 0, 0.25, 0.12, 0.2, 0.9, 0, 0, 0, 0, 25); //Shoe
		    
    NEMO(-0.15, -0.6, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); //Right Leg  
    NEMO(-0.25, -0.8, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); 
    NEMO(-0.3, -0.9, 0, 0.1, 0.12, 0.08, 0.9, 0, 0, 0, 0, -25); 
    NEMO(-0.41, -1.1, 0, 0.25, 0.12, 0.2, 0.9, 0, 0, 0, 0, -25); //Shoe 
		 
    glPopMatrix();
}








//For the scene(background)
void draw_scene()
{
   const double chook_len=1.5;  //Axes' Length
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   glEnable(GL_DEPTH_TEST);
   glLoadIdentity();
   //  initializing view angle
   glRotatef(elevat,1,0,0);
   glRotatef(circangle,0,1,0);
    


//3D Objects
   if (YOpower_ranger) 
   { 
      PowerRanger(-2.3, 0.98, -0.5, 0.6, 0, 45, 0); //PowerRanger1
      PowerRanger(0.8, 1, -1.2, 0.6, 0, 0, 0); //PowerRanger2
   }

   if (RainBow)
   {
		BONG(0.7, -1.5, 0.2, 90, 0.1, 0.5, 0.4, 0, 0.5);
		BONG(0.7, -1, 0.2, 90, 0.1, 0.6, 0.4, 0.1, 0.9);
		BONG(0.7, -0.5, 0.2, 90, 0.1, 0.7, 0.4, 0.3, 1); 
		BONG(0.7, 0, 0.2, 90, 0.1, 0.9, 0.4, 1, 0); 
		BONG(0.7, 0.5, 0.2, 90, 0.1, 0.8, 1, 1, 0); 
		BONG(0.7, 1, 0.2, 90, 0.1, 0.7, 0.9, 0.5, 0);    
		BONG(0.7, 1.5, 0.2, 90, 0.1, 0.6, 0.9, 0, 0); 
   }
 
   glColor3f(1,1,1); //Axes

   if (chook)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(chook_len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,chook_len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,chook_len);
      glEnd();
      //For Axes
      glRasterPos3d(chook_len,0.0,0.0);
      characprint("X");
      glRasterPos3d(0.0,chook_len,0.0);
      characprint("Y");
      glRasterPos3d(0.0,0.0,chook_len);
      characprint("Z");
   }
   glWindowPos2i(5,5);
   characprint("View Angle=%d,%d",circangle,elevat);
   glFlush();
   glutSwapBuffers();
}

//Hotkeys for Arrows
void special_hotkey(int hotkey_press,int hotkey_x,int hotkey_y)
{
   //↑↓→←: View with different angles
   if (hotkey_press == GLUT_KEY_RIGHT)
      circangle += 5;
   else if (hotkey_press == GLUT_KEY_LEFT)
      circangle -= 5;
   else if (hotkey_press == GLUT_KEY_UP)
      elevat += 5;
   else if (hotkey_press == GLUT_KEY_DOWN)
      elevat -= 5;

   
   circangle %= 360; //set angles to +/-360 degrees
   elevat %= 360; //set elevation to +/-360 degrees
   
   glutPostRedisplay();
}


void hotkey_press(unsigned char ch,int hk_press_x,int hk_press_y)
{
   //  Press ESC then Exit the program
   if (ch == 27)
      exit(0);
   // Press 0, then go back to original view(reset)
   else if (ch == '0')
      circangle = elevat = 0;
   // Show/Hide Axes
   else if (ch == 'a' || ch == 'A')
      chook = 1-chook;
   //  Show/Hide PowerRangers
   else if (ch == 'p' || ch == 'P')
      YOpower_ranger = 1-YOpower_ranger;
   // Show/Hide Rainbow
   else if (ch == 'r' || ch == 'R')
      RainBow = 1-RainBow;
  
   glutPostRedisplay();
}

//Reshape
void shapeRedraw(int width,int height)
{
   const double dim=2.5;
   double widnheight = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-widnheight*dim,+widnheight*dim, -dim,+dim, -dim,+dim);
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}


void idle()
{
   glutPostRedisplay();
}

// Tell GLUT what to do
int main(int argument1,char* argument2[])
{
   glutInit(&argument1,argument2);
   glutInitWindowSize(1060,850);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutCreateWindow("Junwoo Jang - CSCI5229 - HW3, PowerRangers with a RainBow");
   glutIdleFunc(idle);
   #ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal4gl("Error initializing GLEW\n");
   #endif
   glutDisplayFunc(draw_scene);
   glutReshapeFunc(shapeRedraw);
   glutSpecialFunc(special_hotkey);
   glutKeyboardFunc(hotkey_press);
   glutMainLoop();
   return 0;
}
