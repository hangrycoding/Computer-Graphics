
1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./hw3.exe" to execute the program to
view the Lorenz Attractor.


This Program displays Wonderful Twin Red Power Rangers and a beautiful Rainbow
	
*******Hot Keys*******
↑↓→←: View with different angles
0: Original(Reset) view with original angle
ESC: Exit Program
	
a/A: Hide Axes & Show Axes
p/P: Hide PowerRangers & Show PowerRangers
r/R: Hide Rainbow & Show RainBow