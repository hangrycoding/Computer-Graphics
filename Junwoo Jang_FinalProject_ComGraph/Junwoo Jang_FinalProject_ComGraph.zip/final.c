/*
	Junwoo Jang - CSCI 5229 - Final Project 
	
	This Program displays a beautiful neighborhood that has
	houses, a tall building, a tennis court, a swimming pool, a powerranger playing
	beer pong, etc.
	
	***** I think this is one of the interesting/creative things 
	that I am Proud Of by pressing the Keys *****:
	
	1) The PowerRanger gets anxious and the anxious level goes up by pressing
	'a' or 'A' which ends up exploding the powerranger's head.
	
	2) 'g' or 'G' will change the shape of powerranger's hand and it will  hold the gun which will shoot the building.
	The building will start to break down.
	
	
	*******Hot Keys*******
	
	ESC: Exit Program
	0: Original(Reset) view with original angle
	l/L: Toggle the lighting
	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles
	
	Q/q: Increase/Decrease the ambient light
	W/w: Increase/Decrease the diffuse light
	E/e: Increase/Decrease the emitted light
	R/r: Increase/Decrease the specular light
	T/t: Increase/Decrease the shininess
	
	a/A: The more you push this button, the more it makes PowerRanger Anxious
	g/G: PowerRanger gun mode On and OFF: shooting the tall building next to it and the building starts to break down
	d/D: The main door(/gate) open & close
	k/K: TV On & OFF
	
	
	
	
	F1: Toggle the smooth/flat shading
	F2: Toggle the local viewer mode
	F8: Change the  increment
	F9: Invert thebottom normal
	

	z/Z: Toggle the light movement


*/



//Header files
#include <math.h> //standard library  for basic mathematical operations
#include <stdlib.h> //handles memory allocation, process control, conversions and others
#include <stdarg.h> //for  indefinite number of argument
#include <stdio.h> //for input and output
#include <string.h> 
//for OpenGL 
#ifdef USEGLEW 
#include <GL/glew.h> 
#endif 
#define GL_GLEXT_PROTOTYPES 
#ifdef __APPLE__ 
#include <GLUT/glut.h> 
#else 
#include <GL/glut.h> 
#endif 

#include "CSCIx229.h"

int chook=0;   
int orth_per_fp_view=2; 

double BuildingBreak_ROT = 0;



/******* LIGHT RELATED START *********/
double ROT=0; //굴뚝연기랑 ChestBall 위해서 사용되었음
int MovOfLight=1; 

int LIGHT=1;      
int UV=1; 
double DofLight= 1000;  // For the distance of the light : Light 물체들과의거리(즉 움직이는 둘러싸는공과의 내 작품들과의 거리) 

int BallInc=10;  
int sm_flat_shading=1;  
int LocalVIEWER_M=0;  
int EMIS=0; 


int AMB=30;  
int diffuse=100;   
int SPEC=0;  
int SHINE_L=0;  
float SHIN_Y=1;
float Light_elevat=200;  //Light 높이 (즉 움직이는 둘러싸는공 높이) 


/******* LIGHT RELATED END *********/







int YO_MAINGATE = 1;
int TXTURE_MODE=0;     
int YO_TXTURE=0; 
int YO_TV = 1;   





//*****   처음 켰을때 작품 보는각도 코드 part START 

int circangle=-25; //	뷰에서 Angel=(circangle,elevat)임            
int elevat=35; //	뷰에서 Angel=(circangle,elevat)임  

int perspective_view=80; //뷰에서 fov임  
double widnheight_ratio=1; 
double worldsize=440;   //뷰에서 dim임     

//*****   처음 켰을때 작품 보는각도 코드 part END 



double REPETITION=1; 
double xAxis_REPET=1;  
double yAxis_REPET=1;  
 
int circangle_CAM_V = 0;
int elevat_CAM_V = 0;

double BIGEYE_x = 2;
double BIGEYE_y = 10;
double BIGEYE_z = 160;


float SHINE_VAL[1];   
  

float WHT_4_TXTURE[] = {1,1,1,1};
float YELW_4_TXTURE[] = {1,1,0,1};




int anxiety_level_var = 40; 
int OnorOff_MovingRedAnxietyLine = 1;
int RedAnxietyLine_Original_POS = -600;
int PRANGER_FACE_GETBIGGER_VAL = 0; 


int OnorOFF_Pranger_GREENGUN = 1;
int OnorOFf_4_BuildingBreak_ROT_IDLE = 0;



#define LEN 8192 




void characprint(const char* pranger_chrcprint_format , ...)
{
   char    chprint[LEN]; 
   char*   ch_for_pranger_chrcprint=chprint;
   va_list args;
   va_start(args,pranger_chrcprint_format);
   vsnprintf(chprint,LEN,pranger_chrcprint_format,args);
   va_end(args);
   
 
   while (*ch_for_pranger_chrcprint)
      glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*ch_for_pranger_chrcprint++);
}


void Fatal(const char* format , ...)
{
   va_list args;
   va_start(args,format);
   vfprintf(stderr,format,args);
   va_end(args);
   exit(1);
}



void PROJECTION(double perspective_view,double widnheight_ratio,double worldsize) 
{ 
  
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity(); 

   if (perspective_view) 
   {
      gluPerspective(perspective_view,widnheight_ratio,worldsize/16,16*worldsize); 
   }
   else 
   {
      glOrtho(-widnheight_ratio*worldsize,widnheight_ratio*worldsize,-worldsize,+worldsize,-worldsize,+worldsize); 
   }
  
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}


void CheckError(const char* where)  
{ 
   int err = glGetError(); 
   if (err) fprintf(stderr,"ERROR: %s [%s]\n",gluErrorString(err),where);
} 




static void Vertex(double circangle,double elevat)
{
   REPETITION = 1; 
   double vertex_x = Sin(circangle)*Cos(elevat);
   double vertex_y = Cos(circangle)*Cos(elevat);
   double vertex_z = Sin(elevat);

   glNormal3d(vertex_x,vertex_y,vertex_z);
   glTexCoord2d(REPETITION*circangle/360.0,REPETITION*elevat/180.0+0.5);
   //   glColor3f(Cos(circangle)*Cos(circangle), Sin(elevat)*Sin(elevat), Sin(circangle)*Sin(circangle)); 
   //For the beautiful rainbow 공 
   glVertex3d(vertex_x,vertex_y,vertex_z);

}



static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, 
double circangle, double circrad, double circH, 
unsigned int BONG_texture)
{
    double BONG_ang = 0.0;
    double BONG_s = 0.1;
    
	
   float BONG_white[] = {1,1,1,1};
   float BONG_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,BONG_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,BONG_emis); 
    
   glPushMatrix();
    
   glRotatef(circangle, 0, 1, 0); //To Rotate
   glRotatef(circangle, 1, 0, 0); //To Rotate
   glTranslated(BONG_lr,BONG_ud,BONG_fb);
	   
	   
   //  To use textures (enabling)
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,BONG_texture); 
	
	

    if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_QUAD_STRIP);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , circH);
		glTexCoord2f(REPETITION,0);
        glVertex3f(BONG_lr, BONG_ud , 0.0);
		
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,REPETITION);
    glVertex3f(circrad, 0.0, circH);
	glTexCoord2f(0,REPETITION);
    glVertex3f(circrad, 0.0, 0.0);
    glEnd();
    
	
	
    // For the Lid(top circle)
	if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , circH);
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,0);
    glVertex3f(circrad, 0.0, circH);
    glEnd();
    
	
	
    // For the bottom circle
	if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , 0);
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,0);
    glVertex3f(circrad, 0.0, circH);
    glEnd();
  
    glPopMatrix();
	glDisable(GL_TEXTURE_2D); 

    
}


static void NEMO (double NEMO_lr,double NEMO_ud,double NEMO_fb, 
                 double NEMO_size_lr,double NEMO_size_ud,double NEMO_size_fb,
                 double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3, 
				 unsigned int NEMO_txture)
{
	
   float NEMO_white[] = {1,1,1,1}; 
   float NEMO_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO_emis); 
   
   
   glPushMatrix();
   glTranslated(NEMO_lr,NEMO_ud,NEMO_fb);
   glRotated(NEMO_rot_1,1,0,0);
   glRotated(NEMO_rot_1,0,1,0);
   glRotated(NEMO_rot_3,0,0,1);
   glScaled(NEMO_size_lr,NEMO_size_ud,NEMO_size_fb);
  
   //  To use textures (enabling)
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO_txture); 




   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS);
   glNormal3f(0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1, 1);
   glEnd();
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 0, -1); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glEnd(); 
   
   
   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,REPETITION); glVertex3f(+1,+1,+1);  
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(-1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd();
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 1, 0);  
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,+1,+1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd(); 
   



   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f( 0, -1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,-1,+1);
   
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D); 

}


static void NEMO4FACE(double NEMO4FACE_lr,double NEMO4FACE_ud,double NEMO4FACE_fb, 
                 double NEMO4FACE_size_lr,double NEMO4FACE_size_ud,double NEMO4FACE_size_fb,
                 double NEMO4FACE_rot_1, double NEMO4FACE_rot_2, double NEMO4FACE_rot_3, 
				 unsigned int NEMO4FACE_txture)
{
	
   unsigned int NEMO4FACE_txture_rest = LoadTexBMP("txt_redsuit.bmp");
   
   float NEMO4FACE_white[] = {1,1,1,1}; 
   float NEMO4FACE_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO4FACE_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO4FACE_emis); 
   
   
   glPushMatrix();
   glTranslated(NEMO4FACE_lr,NEMO4FACE_ud,NEMO4FACE_fb);
   glRotated(NEMO4FACE_rot_1,1,0,0);
   glRotated(NEMO4FACE_rot_1,0,1,0);
   glRotated(NEMO4FACE_rot_3,0,0,1);
   glScaled(NEMO4FACE_size_lr,NEMO4FACE_size_ud,NEMO4FACE_size_fb);
  
 
   //  To use textures (enabling) for the FACE
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture); 
   
   //The front face
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture);
   glBegin(GL_QUADS);
   glNormal3f(0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1, 1);
   glEnd();
   

   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   
   //The Rest parts except the front
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 0, -1); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glEnd(); 
   
   

   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f( 1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(+1,+1,+1);  
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(-1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd();
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 1, 0);  
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,+1,+1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1);
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f( 0, -1, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,-1,+1);
   
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);

}




static void NEMO4BuildingWall(double NEMO4BuildingWall_lr,double NEMO4BuildingWall_ud,double NEMO4BuildingWall_fb, 
                 double NEMO4BuildingWall_size_lr,double NEMO4BuildingWall_size_ud,double NEMO4BuildingWall_size_fb,
                 double NEMO4BuildingWall_rot_1, double NEMO4BuildingWall_rot_2, double NEMO4BuildingWall_rot_3, 
				 unsigned int NEMO4BuildingWall_txture_Front, unsigned int NEMO4BuildingWall_txture_Back, 
				 unsigned int NEMO4FACE_txture_side_RIGHT,unsigned int NEMO4FACE_txture_side_LEFT,
				 unsigned int NEMO4FACE_txture_UP,unsigned int NEMO4FACE_txture_DOWN)
			
{
	



   float NEMO4FACE_white[] = {1,1,1,1}; 
   float NEMO4FACE_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO4FACE_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO4FACE_emis); 
   
   
   glPushMatrix();
   glTranslated(NEMO4BuildingWall_lr,NEMO4BuildingWall_ud,NEMO4BuildingWall_fb);
   glRotated(NEMO4BuildingWall_rot_1,1,0,0);
   glRotated(NEMO4BuildingWall_rot_1,0,1,0);
   glRotated(NEMO4BuildingWall_rot_3,0,0,1);
   glScaled(NEMO4BuildingWall_size_lr,NEMO4BuildingWall_size_ud,NEMO4BuildingWall_size_fb);
  
 
// ******    FRONT SIDE START  *************  
 
   //  To use textures (enabling) for the FRONT
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4BuildingWall_txture_Front); 
   
   //앞면
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4BuildingWall_txture_Front);
   glBegin(GL_QUADS);
   glNormal3f(0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1, 1);
   glEnd();
   
// ******    FRONT SIDE END  *************  
   
   
// ******    BACK SIDE START  *************  
   //  To use textures (enabling) for the BACK
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4BuildingWall_txture_Back); 
   
   
   //뒷면 (내면)
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4BuildingWall_txture_Back);
   glBegin(GL_QUADS); 
   glNormal3f(0, 0, -1); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glEnd(); 
// ******    BACK SIDE END  *************  
   

// ******    RIGHT SIDE START  *************  
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_side_RIGHT); 
   
   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_side_RIGHT); 
   glBegin(GL_QUADS); 
   glNormal3f( 1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(+1,+1,+1);  
   glEnd(); 
// ******    RIGHT SIDE END  *************  



// ******    LEFT SIDE START  *************  

   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_side_LEFT); 

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_side_LEFT); 
   glBegin(GL_QUADS); 
   glNormal3f(-1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd();
// ******    LEFT SIDE END  *************  

   
// ******    UP SIDE START  *************  

   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_UP); 
   
   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_UP); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 1, 0);  
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,+1,+1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1);
   glEnd(); 
   
   
// ******    UP SIDE END  *************  

// ******    DOWN SIDE START  *************  

   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_DOWN); 
   
   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_DOWN); 
   glBegin(GL_QUADS); 
   glNormal3f( 0, -1, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,-1,+1);
   
   
// ******    DOWN SIDE END  *************  
   
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);

}









void NEMO4HOUSES(
	double NEMO4HOUSES_lr,double NEMO4HOUSES_ud,double NEMO4HOUSES_fb,
	double NEMO4HOUSES_size_lr,double NEMO4HOUSES_size_ud,double NEMO4HOUSES_size_fb,
    double NEMO4HOUSES_circangle)
{
   glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,SHINE_VAL);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,WHT_4_TXTURE);
   
   glPushMatrix();
   glTranslated(NEMO4HOUSES_lr,NEMO4HOUSES_ud,NEMO4HOUSES_fb);
   glRotated(NEMO4HOUSES_circangle,0,1,0);
   glScaled(NEMO4HOUSES_size_lr,NEMO4HOUSES_size_ud,NEMO4HOUSES_size_fb);
   
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   

	   
   glBegin(GL_QUADS);
   
   
   glNormal3f( 0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1, 1);
   
   glNormal3f( 0, 0, -1);
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(+1,+1,-1);
   
   glNormal3f( 1, 0, 0);
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(+1,+1,+1);
   
   glNormal3f(-1, 0, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,-1);
   
   glNormal3f( 0, 1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,+1,+1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,-1);
   
   glNormal3f( 0, -1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,-1,+1);
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);
}












static void GONG(double GONG_lr,double GONG_ud,double GONG_fb,double GONG_BAN_JIREUM)
{
   const int GONG_DISTANCE=5;
   int circangle,elevat;
   float YELW_4_TXTURE[] = {1.0,1.0,0.0,1.0};
   float Emission[]  = {0.0,0.0,0.01*EMIS,1.0};
   
   glPushMatrix();
   glTranslated(GONG_lr,GONG_ud,GONG_fb);
   glScaled(GONG_BAN_JIREUM,GONG_BAN_JIREUM,GONG_BAN_JIREUM);
   
   

   glMaterialfv(GL_FRONT,GL_SHININESS,SHINE_VAL);
   glMaterialfv(GL_FRONT,GL_SPECULAR,YELW_4_TXTURE);
   glMaterialfv(GL_FRONT,GL_EMISSION,Emission);
   
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
 

   for (elevat=-90;elevat<90;elevat+=GONG_DISTANCE)
   {
      glBegin(GL_QUAD_STRIP);
      for (circangle=0;circangle<=360;circangle+=GONG_DISTANCE)
      {
         Vertex(circangle,elevat);
         Vertex(circangle,elevat+GONG_DISTANCE);
      }
      glEnd();
   }
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);
}



static void ball(double BALL_x,double BALL_y,double BALL_z,double BALL_r)  
{ 
   int BALL_circangle,BALL_elevat; 
   float BALL_norang[] = {1.0,1.0,0.0,1.0};  
   float BALL_emis[]  = {0.0,0.0,0.01*EMIS,1.0};  
   
   glPushMatrix();  
   glTranslated(BALL_x,BALL_y,BALL_z);  
   glScaled(BALL_r,BALL_r,BALL_r); 
  
   glColor3f(1,1,1); // Ball color set up 
   glMaterialf(GL_FRONT,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT,GL_SPECULAR,BALL_norang); 
   glMaterialfv(GL_FRONT,GL_EMISSION,BALL_emis); 



   for (BALL_elevat=-90;BALL_elevat<90;BALL_elevat+=BallInc)  
   { 
      glBegin(GL_QUAD_STRIP);  
      for (BALL_circangle=0;BALL_circangle<=360;BALL_circangle+=2*BallInc)  
      { 
         Vertex(BALL_circangle,BALL_elevat);  
         Vertex(BALL_circangle,BALL_elevat+BallInc); 
      }  
      glEnd(); 
   } 
   
   glPopMatrix(); 
}  




void BASE4BIGGYHOUSE(double BASE4BIGGYHOUSE_lr,double BASE4BIGGYHOUSE_ud,double BASE4BIGGYHOUSE_fb,
double BASE4BIGGYHOUSE_size_lr,double BASE4BIGGYHOUSE_size_ud,double BASE4BIGGYHOUSE_size_fb,
double circangle)
{  

   unsigned int txt_walls_inBASE4BIGGYHOUSE = LoadTexBMP("txt_greyBrickwalls.bmp");
   unsigned int txt_Floor_inBASE4BIGGYHOUSE = LoadTexBMP("txt_floor.bmp");
   unsigned int txt_WallB_inBASE4BIGGYHOUSE = LoadTexBMP("txt_popcornWall.bmp");

   xAxis_REPET = 4;
   yAxis_REPET = 1;
   
   glPushMatrix();
   glTranslated(BASE4BIGGYHOUSE_lr,BASE4BIGGYHOUSE_ud,BASE4BIGGYHOUSE_fb);
   glRotated(circangle,0,1,0);
   glScaled(BASE4BIGGYHOUSE_size_lr,BASE4BIGGYHOUSE_size_ud,BASE4BIGGYHOUSE_size_fb);
   
   glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,SHINE_VAL);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,WHT_4_TXTURE);
   
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   glBindTexture(GL_TEXTURE_2D,txt_walls_inBASE4BIGGYHOUSE);
 
   glBegin(GL_QUADS);
   glNormal3f( 0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1, 1);
   
   
   glNormal3f( 0, 0, -1);
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(+1,+1,-1);
   
   glNormal3f( 1, 0, 0);
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(+1,+1,+1);
   glEnd();
   
   
   glBindTexture(GL_TEXTURE_2D,txt_WallB_inBASE4BIGGYHOUSE);
   glBegin(GL_QUADS);
   glNormal3f( 0, 0, -1);
   glTexCoord2f(0,0); glVertex3f(+1,-1,-0.99);
   glTexCoord2f(1,0); glVertex3f(-1,-1,-0.99);
   glTexCoord2f(1,1); glVertex3f(-1,+1,-0.99);
   glTexCoord2f(0,1); glVertex3f(+1,+1,-0.99);
   glEnd();
   
   glBindTexture(GL_TEXTURE_2D,txt_walls_inBASE4BIGGYHOUSE);
   glBegin(GL_QUADS);
   glNormal3f(-1, 0, 0);
   
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-1,-1,-0.2);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-1,+1,-0.2);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,-1);
   
   glNormal3f(-1, 0, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,0.2);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,0.2);
   
   glNormal3f(-1, 0, 0);
   glTexCoord2f(0,0); glVertex3f(-1,0.4,-0.2);
   glTexCoord2f(0.75,0); glVertex3f(-1,0.4,0.2);
   glTexCoord2f(0.75,0.5); glVertex3f(-1,+1,0.2);
   glTexCoord2f(0,0.5); glVertex3f(-1,+1,-0.2);
   glEnd();
   

   glBegin(GL_QUADS);
   glVertex3f(-0.99,-1,-1);
   glVertex3f(-0.99,-1,-0.2);
   glVertex3f(-0.99,+1,-0.2);
   glVertex3f(-0.99,+1,-1);
     
   glVertex3f(-0.99,-1,0.2);
   glVertex3f(-0.99,-1,+1);
   glVertex3f(-0.99,+1,+1);
   glVertex3f(-0.99,+1,0.2);
   
   glVertex3f(-0.99,0.4,-0.2);
   glVertex3f(-0.99,0.4,0.2);
   glVertex3f(-0.99,+1,0.2);
   glVertex3f(-0.99,+1,-0.2);  
   
   glNormal3f( 0, 1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,+1,0.18);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,+1,+0.18);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,-1);
   
   glNormal3f( 0, 1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,+1,1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,+1,+1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,+1,0.3);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,0.3);
   
   glNormal3f( 0, 1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,+1,0.3);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(-0.2,+1,0.3);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(-0.2,+1,0.18);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,+1,0.18);
   
   glNormal3f( 0, 1, 0);
   glTexCoord2f(0,0); glVertex3f(0.2,+1,0.3);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(1,+1,0.3);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(1,+1,0.18);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(0.2,+1,0.18);
     
   glNormal3f( 0, -1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(xAxis_REPET,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(xAxis_REPET,yAxis_REPET); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,yAxis_REPET); glVertex3f(-1,-1,+1);
   glEnd();
   
   glBindTexture(GL_TEXTURE_2D,txt_Floor_inBASE4BIGGYHOUSE);
   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex3f(-1,-0.99,-1);
   glTexCoord2f(5,0); glVertex3f(+1,-0.99,-1);
   glTexCoord2f(5,5); glVertex3f(+1,-0.99,+1);
   glTexCoord2f(0,5); glVertex3f(-1,-0.99,+1);
   glEnd();
   glDisable(GL_TEXTURE_2D);

   glBegin(GL_QUADS);
   glTexCoord2f(0,0); glVertex3f(+0.94,-1,+1);
   glTexCoord2f(1,0); glVertex3f(+0.94,-1,-1);
   glTexCoord2f(1,1); glVertex3f(+0.94,+1,-1);
   glTexCoord2f(0,1); glVertex3f(+0.94,+1,+1); 
   
   glNormal3f( 0, 0, 1); 
   glTexCoord2f(0,0); glVertex3f(-1,-1, 0.94);
   glTexCoord2f(1,0); glVertex3f(+1,-1, 0.94);
   glTexCoord2f(1,1); glVertex3f(+1,+1, 0.94);
   glTexCoord2f(0,1); glVertex3f(-1,+1, 0.94);
   glEnd();
   
   glPopMatrix();
}


void BONG4TREE (double BONG4TREE_lr, double BONG4TREE_ud, double BONG4TREE_fb,
double circangle, double elevat,
double BONG4TREE_BANJI, double BONG4TREE_NOPI)
{
	int BONG4TREE_i,BONG4TREE_o;
	
   glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,SHINE_VAL);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,WHT_4_TXTURE);
 
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   
   glPushMatrix();
   glTranslated(BONG4TREE_lr,BONG4TREE_ud,BONG4TREE_fb);
   glRotated(circangle,0,1,0);
   glRotated(elevat,1,0,0);
   glScaled(BONG4TREE_BANJI,BONG4TREE_BANJI,BONG4TREE_NOPI);

  
	   
   for (BONG4TREE_i=1;BONG4TREE_i>=-1;BONG4TREE_i-=2)
   {
      glNormal3f(0,0,BONG4TREE_i);
      glBegin(GL_TRIANGLE_FAN);
      glTexCoord2f(0.5,0.5);
      glVertex3f(0,0,BONG4TREE_i);
      for (BONG4TREE_o=0;BONG4TREE_o<=360;BONG4TREE_o+=10)
      {
         glTexCoord2f(0.5*Cos(BONG4TREE_o)+0.5,0.5*Sin(BONG4TREE_o)+0.5);
         glVertex3f(BONG4TREE_i*Cos(BONG4TREE_o),Sin(BONG4TREE_o),BONG4TREE_i);
      }
      glEnd();
   }

 
   glBegin(GL_QUAD_STRIP);
   for (BONG4TREE_o=0;BONG4TREE_o<=360;BONG4TREE_o+=10)
   {
      glNormal3f(Cos(BONG4TREE_o),Sin(BONG4TREE_o),0);
      glTexCoord2f(0,0.5*BONG4TREE_o); 
	  glVertex3f(Cos(BONG4TREE_o),Sin(BONG4TREE_o),+1);
      glTexCoord2f(1,0.5*BONG4TREE_o); 
	  glVertex3f(Cos(BONG4TREE_o),Sin(BONG4TREE_o),-1);
   }
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);
 
}




void Wall4FENCE(double Wall4FENCE_lr,double Wall4FENCE_ud,double Wall4FENCE_fb,
double Wall4FENCE_size_lr,double Wall4FENCE_size_ud,double Wall4FENCE_size_fb,
double circangle)
{
   
   unsigned int txt_theMAINDOOR_in_Wall4FENCE = LoadTexBMP("txt_main_door.bmp");
   unsigned int txt_BricksFence_in_Wall4FENCE = LoadTexBMP("txt_bricks_fence.bmp");

	

   glPushMatrix();
   glTranslated(Wall4FENCE_lr,Wall4FENCE_ud,Wall4FENCE_fb);
   glRotated(circangle,0,1,0);
   glScaled(Wall4FENCE_size_lr,Wall4FENCE_size_ud,Wall4FENCE_size_fb);
   
   glMaterialfv(GL_FRONT_AND_BACK,GL_SHININESS,SHINE_VAL);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,WHT_4_TXTURE);
   
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);
   
   glBindTexture(GL_TEXTURE_2D,txt_BricksFence_in_Wall4FENCE);
   glBegin(GL_QUADS);
   
   
   glNormal3f(0,0,-1);
   glTexCoord2f(0,0); glVertex3f(-1,-1,1.5);
   glTexCoord2f(2,0); glVertex3f(+1,-1,1.5);
   glTexCoord2f(2,1); glVertex3f(+1,+1,1.5);
   glTexCoord2f(0,1); glVertex3f(-1,+1,1.5);
   
   glNormal3f(0,0,1);
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(2,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(2,1); glVertex3f(-1,+1,-1);
   glTexCoord2f(0,1); glVertex3f(+1,+1,-1);
   
   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1.5);
   glTexCoord2f(4,0); glVertex3f(+1,-1,-1);
   glTexCoord2f(4,1); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,1); glVertex3f(+1,+1,+1.5);
   
   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(4,0); glVertex3f(-1,-1,+0.5);
   glTexCoord2f(4,1); glVertex3f(-1,+1,+0.5);
   glTexCoord2f(0,1); glVertex3f(-1,+1,-1);
   
   glTexCoord2f(0,0); glVertex3f(-1,-1,+1.5);
   glTexCoord2f(2,0); glVertex3f(-1,-1,+0.8);
   glTexCoord2f(2,1); glVertex3f(-1,+1,+0.8);
   glTexCoord2f(0,1); glVertex3f(-1,+1,+1.5);
   glEnd();
   
   glBindTexture(GL_TEXTURE_2D,txt_theMAINDOOR_in_Wall4FENCE);
   glBegin(GL_QUADS);
   glNormal3f(-1, 0, 0);

   if(YO_MAINGATE == 0){
	    glNormal3f(0, 0, 1);
	    glTexCoord2f(0,0); glVertex3f(-0.4,-1,+0.8);
		glTexCoord2f(1,0); glVertex3f(-1,-1,+0.8);
		glTexCoord2f(1,1); glVertex3f(-1,+1,+0.8);
		glTexCoord2f(0,1); glVertex3f(-0.4,+1,+0.8);
	} else {
		glNormal3f(-1, 0, 0);
	    glTexCoord2f(0,0); glVertex3f(-1,-1,+0.5);
		glTexCoord2f(1,0); glVertex3f(-1,-1,+0.8);
		glTexCoord2f(1,1); glVertex3f(-1,+1,+0.8);
		glTexCoord2f(0,1); glVertex3f(-1,+1,+0.5);
   }	   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);
}




void ULTARI(
	double ULTARI_lr,double ULTARI_ud,double ULTARI_fb,
	double ULTARI_size_lr,double ULTARI_size_ud,double ULTARI_size_fb,
    double circangle, double elevat)
{	
   glPushMatrix();
   glTranslated(ULTARI_lr,ULTARI_ud,ULTARI_fb);
   glRotated(circangle,0,1,0);
   glRotated(elevat,1,0,0);
   glScaled(ULTARI_size_lr,ULTARI_size_ud,ULTARI_size_fb);

   Wall4FENCE(0,1.2,0,1,2,1,0);
   
   glPopMatrix();
}



void NAMOO_A( double NAMOO_A_lr, double NAMOO_A_ud, double NAMOO_A_fb, 
double NAMOO_A_size_lr, double NAMOO_A_size_ud, double NAMOO_A_size_fb, 
double circangle, double elevat,
double NAMOO_A_BANJI)
{
	glPushMatrix();
	glTranslated(NAMOO_A_lr,NAMOO_A_ud,NAMOO_A_fb);
	glRotated(circangle,0,1,0);
	glRotated(elevat,1,0,0);
	glScaled(NAMOO_A_size_lr,NAMOO_A_size_ud,NAMOO_A_size_fb);
	
	glColor3f(0.53,0.16,0.02);
	BONG4TREE(0,0,0,0,90,1.75,20);
	
	glColor3f(0,0.8,0); //tree색깔
    GONG(-5,15,1,NAMOO_A_BANJI);
    GONG(5,15,1,NAMOO_A_BANJI);
    GONG(0,25,1,NAMOO_A_BANJI); 
			
	glPopMatrix();
}

void NAMOO_B( double NAMOO_B_lr, double NAMOO_B_ud, double NAMOO_B_fb, 
double NAMOO_B_size_lr, double NAMOO_B_size_ud, double NAMOO_B_size_fb, 
double circangle, double elevat,
double NAMOO_B_BANJI)
{
	glPushMatrix();
	glTranslated(NAMOO_B_lr,NAMOO_B_ud,NAMOO_B_fb);
	glRotated(circangle,0,1,0);
	glRotated(elevat,1,0,0);
	glScaled(NAMOO_B_size_lr,NAMOO_B_size_ud,NAMOO_B_size_fb);
	
	glColor3f(0.53,0.16,0.02);
	BONG4TREE(0,0,0,0,90,1.75,20);
	
	glColor3f(0.6,1,1); //tree색깔
    GONG(-8,15,1,NAMOO_B_BANJI);
    GONG(8,15,1,NAMOO_B_BANJI);
    GONG(-5,25,1,NAMOO_B_BANJI-1);
    GONG(5,25,1,NAMOO_B_BANJI-1);
    GONG(0,35,1,NAMOO_B_BANJI-2);
	GONG(0,25,-5,NAMOO_B_BANJI-2);
	GONG(0,25,5,NAMOO_B_BANJI-2);
			
	glPopMatrix();
}
	

 
//그냥 집 지붕만임 START 
static void SmallyZIP4_2flr(
	double SmallyZIP4_2flr_lr,double SmallyZIP4_2flr_ud,double SmallyZIP4_2flr_fb,
	double SmallyZIP4_2flr_size_lr,double SmallyZIP4_2flr_size_ud,double SmallyZIP4_2flr_size_fb,
	double circangle,double elevat)
{
	
	
   unsigned int txt_ROOF_in_SmallyZIP4_2flr = LoadTexBMP("txt_roof.bmp");
   
   
   float NEMO4FACE_white[] = {1,1,1,1}; 
   float NEMO4FACE_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO4FACE_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO4FACE_emis); 

	
   glPushMatrix();
   glTranslated(SmallyZIP4_2flr_lr,SmallyZIP4_2flr_ud,SmallyZIP4_2flr_fb);
   glRotated(circangle,0,1,0);
   glRotated(elevat,1,0,0);
   glScaled(SmallyZIP4_2flr_size_lr,SmallyZIP4_2flr_size_ud,SmallyZIP4_2flr_size_fb);
   

   
   

   
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV , GL_TEXTURE_ENV_MODE , GL_MODULATE);

 
   
   glBindTexture(GL_TEXTURE_2D,txt_ROOF_in_SmallyZIP4_2flr);
   glBegin(GL_QUADS);
   glNormal3f(0,1,0);
   
   glTexCoord2f(0,0); glVertex3f(-1.2,+2,+1.2);
   glTexCoord2f(2,0); glVertex3f(+1.2,+2,+1.2);
   glTexCoord2f(2,2); glVertex3f(+1.2,+2,-1.2);
   glTexCoord2f(0,2); glVertex3f(-1.2,+2,-1.2);
   
   glTexCoord2f(0,0); glVertex3f(-1.2,+2.01,+1.2);
   glTexCoord2f(2,0); glVertex3f(+1.2,+2.01,+1.2);
   glTexCoord2f(2,2); glVertex3f(+1.2,+2.01,-1.2);
   glTexCoord2f(0,2); glVertex3f(-1.2,+2.01,-1.2);
   
   glNormal3f(0,-1,1);
   glTexCoord2f(0,0); glVertex3f(-1.2,+2,+1.2);
   glTexCoord2f(2,0); glVertex3f(+1.2,+2,+1.2);
   glTexCoord2f(2,2); glVertex3f(+1.2,+3,0);
   glTexCoord2f(0,2); glVertex3f(-1.2,+3,0);
  
   glNormal3f(0,-1,-1);
   glTexCoord2f(0,0); glVertex3f(-1.2,+3,0);
   glTexCoord2f(2,0); glVertex3f(+1.2,+3,0);
   glTexCoord2f(2,2); glVertex3f(+1.2,+2,-1.2);
   glTexCoord2f(0,2); glVertex3f(-1.2,+2,-1.2);


  
   glNormal3f(-1,0,0);
   glTexCoord2f(0,0); glVertex3f(-1.2,+3,0);
   glTexCoord2f(1,0); glVertex3f(-1.2,+2,-1.2);
   glTexCoord2f(1,1); glVertex3f(-1.2,+2,+1.2);
   glTexCoord2f(0,0); glVertex3f(-1.2,+3,0);
	
   glNormal3f(1,0,0);
   glTexCoord2f(0,0); glVertex3f(1.2,+3,0);
   glTexCoord2f(1,0); glVertex3f(1.2,+2,-1.2);
   glTexCoord2f(1,1); glVertex3f(1.2,+2,+1.2);
   glTexCoord2f(0,0); glVertex3f(1.2,+3,0);
 


    
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);
}

//그냥 집 지붕만임 END 



void idle()
{
   double idle_time = glutGet(GLUT_ELAPSED_TIME)/1000.0;
   
   
   ROT = fmod(90*idle_time,360.0);
   if (OnorOFf_4_BuildingBreak_ROT_IDLE == 1)
   {
	    double idle_time_4_Building_Break = glutGet(GLUT_ELAPSED_TIME)/20000.0;
		BuildingBreak_ROT = fmod(90*idle_time_4_Building_Break,360.0);
   }
   else
   {
   }

   glutPostRedisplay();
   
}

void draw_scene()
{

    unsigned int txt_wt_floor = LoadTexBMP("txt_whitefloor.bmp");
    unsigned int txt_PoolWater = LoadTexBMP("txt_pwater.bmp");
    unsigned int txt_TCourt_F = LoadTexBMP("txt_Tennis_Floor.bmp");
    unsigned int txt_Tennis_Line = LoadTexBMP("txt_Tennis_Line.bmp");
    unsigned int txt_PPnet = LoadTexBMP("txt_PPnet.bmp");
    unsigned int txt_PPtable = LoadTexBMP("txt_PPtable.bmp");
    unsigned int txt_BlackTVBackground = LoadTexBMP("txt_BlackTVBackground.bmp");
    unsigned int txt_brokenTVscreen = LoadTexBMP("txt_brokenTVscreen.bmp");
   
    unsigned int txt_face = LoadTexBMP("txt_face.bmp");
	unsigned int txt_PPmetal = LoadTexBMP("txt_PPmetal.bmp");
    unsigned int txt_pongcup_RED = LoadTexBMP("txt_pongcup_RED.bmp");


	unsigned int txt_CHECK = LoadTexBMP("txt_check.bmp");
	unsigned int txt_SOCKS = LoadTexBMP("txt_socks.bmp");
	unsigned int txt_RED = LoadTexBMP("txt_redsuit.bmp");
	unsigned int txt_RAINBOW = LoadTexBMP("txt_rainbow.bmp");
	unsigned int txt_K_Flag = LoadTexBMP("txt_k_flag.bmp");
	unsigned int txt_badchim = LoadTexBMP("txt_badchim.bmp");
	unsigned int txt_pongcup_BLUE = LoadTexBMP("txt_pongcup_BLUE.bmp");

	unsigned int txt_BIKE_MINT_A = LoadTexBMP("txt_BIKE_MINT_A.bmp");
	unsigned int txt_BIKE_MINT_B = LoadTexBMP("txt_BIKE_MINT_B.bmp");
	unsigned int txt_BROWN_BRICK = LoadTexBMP("txt_BROWN_BRICK.bmp");
    unsigned int txt_BROWN_MAINDOOR = LoadTexBMP("txt_BROWN_MAINDOOR.bmp");
	unsigned int txt_window_A = LoadTexBMP("txt_window_A.bmp");
    unsigned int txt_window_B = LoadTexBMP("txt_window_B.bmp");
    unsigned int txt_window_C = LoadTexBMP("txt_window_C.bmp");
    unsigned int txt_ModernHomeDoor = LoadTexBMP("txt_ModernHomeDoor.bmp");
    unsigned int txt_grey = LoadTexBMP("txt_grey.bmp");

	//unsigned int txt_SHOOT = LoadTexBMP("txt_shoots.bmp");
	//unsigned int txt_PINK = LoadTexBMP("txt_pink.bmp");


//For Building or Houses START
	unsigned int txt_FLOOR = LoadTexBMP("txt_floor.bmp");
	unsigned int txt_buildingwindow = LoadTexBMP("txt_buildingwindow.bmp");
	unsigned int txt_popcornWall = LoadTexBMP("txt_popcornWall.bmp");
	unsigned int txt_bochoong_wall = LoadTexBMP("txt_bochoong_wall.bmp");
	unsigned int txt_greyBrickwalls = LoadTexBMP("txt_greyBrickwalls.bmp");
//For Building or Houses END
  
  
  
   const double chook_len=80;  
   
   OnorOFf_4_BuildingBreak_ROT_IDLE = 0;




   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT); 
   glEnable(GL_DEPTH_TEST); 
   glLoadIdentity(); 
   
//첫 사람 뷰 
   if (orth_per_fp_view == 1) 
   { 
      double FP_View_X = +2*worldsize*Sin(circangle_CAM_V)*Cos(elevat_CAM_V); 
	  double FP_View_Y = -2*worldsize*Sin(elevat_CAM_V);
      double FP_View_Z = -2*worldsize*Cos(circangle_CAM_V)*Cos(elevat_CAM_V);
	  
		  
	  gluLookAt(BIGEYE_x,BIGEYE_y,BIGEYE_z , BIGEYE_x+FP_View_X, BIGEYE_y+FP_View_Y, BIGEYE_z+FP_View_Z , 0,Cos(elevat_CAM_V),0);
	  
   }  
   
   
//퍼스펙티브 뷰 - 세트 아이 위치
   if (orth_per_fp_view == 2)
   {
      double BIGEYE_x = -2*worldsize*Sin(circangle)*Cos(elevat);
      double BIGEYE_y = +2*worldsize*Sin(elevat);
      double BIGEYE_z = +2*worldsize*Cos(circangle)*Cos(elevat);
      gluLookAt(BIGEYE_x,BIGEYE_y,BIGEYE_z,0,0,0,0,Cos(elevat),0);
   }
//올쏘고널 뷰  - 세트 월드 고정방향
   else
   {
      glRotatef(elevat,1,0,0);
      glRotatef(circangle,0,1,0);
   }
   

     glShadeModel(sm_flat_shading ? GL_SMOOTH : GL_FLAT);
	 
	 
   if (LIGHT) 
   {  
        
        float LIGHT_amb[]   = {0.01*AMB ,0.01*AMB ,0.01*AMB ,1.0}; 
        float LIGHT_Diffuse[]   = {0.01*diffuse ,0.01*diffuse ,0.01*diffuse ,1.0};  
        float LIGHT_SPEC[]  = {0.01*SPEC,0.01*SPEC,0.01*SPEC,1.0};  
        float LIGHT_Pos[]  = {DofLight*Cos(ROT),Light_elevat,DofLight*Sin(ROT),1.0}; 
        
		glColor3f(1,1,1); 
        ball(LIGHT_Pos[0],LIGHT_Pos[1],LIGHT_Pos[2] , 10);  
        glEnable(GL_NORMALIZE); 
        glEnable(GL_LIGHTING);  
        glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,LocalVIEWER_M);  
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE);  
        glEnable(GL_COLOR_MATERIAL);  
        glEnable(GL_LIGHT0);  
        glLightfv(GL_LIGHT0,GL_AMBIENT ,LIGHT_amb);  
        glLightfv(GL_LIGHT0,GL_DIFFUSE ,LIGHT_Diffuse); 
        glLightfv(GL_LIGHT0,GL_SPECULAR,LIGHT_SPEC); 
        glLightfv(GL_LIGHT0,GL_POSITION,LIGHT_Pos); 
   } 
   else   
   { 
     glDisable(GL_LIGHTING);   
   } 
   
   

//Main Base Floor START 
   NEMO(50, -2, 0,   400, 5, 300,      0, 0, 0, txt_wt_floor); 
//Main Base Floor END 


   //NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-위로, 
   //양옆길이,두께(높낮이),위아래길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor
   
   NEMO(-550, -2, 0,    200, 5, 300,   0, 0, 0, txt_wt_floor); //Front floor infrontofdoor
   NEMO(-550, 21, 240,    195,15, 60,   0, 0, 0, txt_badchim); //비어퐁컵 받침대 Front floor 걷치대 for beer pong cups


       
   
   
//**********  Draw All Houses  START  
   

   
   
   
// ---------- 내가 다시만든 새로운 신세대 2층집 START

   
//	GONG(-일수록 더왼쪽+일수록오른쪽,B, -일수록 벨트에서거리멀어짐 + ROT /(*로하면빨라짐) 15(숫자낮을수록도 빨라짐),     반지름길이(공크기) ); 


   
   //	NEMO4BuildingWall(-40, 77, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); 
   //NEMO(-40, 10, -130,    80,3, 50,   0, 0, 0, txt_FLOOR);  //for building 1st floor

   NEMO(340,10,-120,   90,3,50,     0, 0, 0, txt_BIKE_MINT_A); 
   
   NEMO4BuildingWall(340, 77, -67,   90,70, 3,   0, 0, 0, txt_PPmetal, txt_BIKE_MINT_B, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor front
   NEMO4BuildingWall(340, 77, -173,   90,70, 3,   0, 0, 0, txt_BIKE_MINT_B, txt_PPmetal, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor- Back

	NEMO4BuildingWall(430, 77, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_PPmetal,txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal ); //1st floor- Left
	NEMO4BuildingWall(250, 77, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal,txt_PPmetal ); //1st floor- right
    
	
	
	NEMO4BuildingWall(260, 155, -110,   180,10, 70,   0, 0, 0, txt_greyBrickwalls, txt_greyBrickwalls, txt_greyBrickwalls,txt_greyBrickwalls,txt_greyBrickwalls,txt_greyBrickwalls ); //1st floor- right



   NEMO4BuildingWall(350, 230, -67,   70,70, 3,   0, 0, 0, txt_PPmetal, txt_BIKE_MINT_B, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor Back
   NEMO4BuildingWall(350, 230, -173,  70,70, 3,   0, 0, 0, txt_BIKE_MINT_B, txt_PPmetal, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor- Back
	NEMO4BuildingWall(420, 230, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_PPmetal,txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal ); //1st floor- Left
	NEMO4BuildingWall(280, 230, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal,txt_PPmetal ); //1st floor- right
    
	
	
	
	NEMO4BuildingWall(170, 230, -67,   70,70, 3,   0, 0, 0, txt_PPmetal, txt_BIKE_MINT_B, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor Back
   NEMO4BuildingWall(170, 230, -173,  70,70, 3,   0, 0, 0, txt_BIKE_MINT_B, txt_PPmetal, txt_PPmetal,txt_PPmetal,txt_PPmetal,txt_PPmetal); //1st floor- Back
	NEMO4BuildingWall(240, 230, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_PPmetal,txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal ); //1st floor- Left
	NEMO4BuildingWall(100, 230, -121,   3,70, 55,   0, 0, 0, txt_PPmetal, txt_PPmetal, txt_BIKE_MINT_B,txt_PPmetal,txt_PPmetal,txt_PPmetal ); //1st floor- right
    

	NEMO4BuildingWall(260, 300, -120,   175,3, 70,   0, 0, 0, txt_greyBrickwalls, txt_greyBrickwalls, txt_greyBrickwalls,txt_greyBrickwalls,txt_greyBrickwalls,txt_greyBrickwalls ); //1st floor- right





   NEMO(360, 340, -122,    20,50, 30,   0, 0, 0, txt_BROWN_BRICK); //집 굴뚝
   NEMO(360, 390, -122,    18,2, 28,   0, 0, 0, txt_wt_floor); //집 굴뚝 하얀구멍
   GONG(360, 430+ ROT / 1, -122, 20); //굴뚝 연기

   NEMO(310, 75, -60,    50,60, 2,   0, 0, 0, txt_BROWN_MAINDOOR); 


   NEMO(395, 100, -60,    30,20, 2,   0, 0, 0, txt_window_C); 
   NEMO(395, 50, -60,    30,20, 2,   0, 0, 0, txt_window_C); 

   NEMO(380, 230, -60,    30,50, 2,   0, 0, 0, txt_window_A); //2층창문
    NEMO(315, 230, -60,    30,50, 2,   0, 0, 0, txt_window_A); //2층창문

   
   
   NEMO(170, 230, -60,    50,40, 2,   0, 0, 0, txt_window_B); //2층창문

// ---------- 내가 다시만든 새로운 신세대 2층집 END

   //NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-위로, 
   //양옆길이,두께(높낮이),위아래길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor
   
   

// +++++++++++++++++++ 내가 다시만든 신세대집의 조그마한 집 START
  SmallyZIP4_2flr(160,60,-130,   45,20,60,    90,0);//그냥 지붕만임
  NEMO(160, 40, -75,    20,25, 2,   0, 0, 0, txt_ModernHomeDoor); 
  
  
  
  NEMO(160,5,-120,   50,3,40,     0, 0, 0, txt_bochoong_wall); 
   
   NEMO4BuildingWall(160, 50, -80,   50,50, 3,   0, 0, 0, txt_BROWN_BRICK, txt_popcornWall, txt_BROWN_BRICK,txt_BROWN_BRICK,txt_BROWN_BRICK,txt_BROWN_BRICK); //1st floor front
   NEMO4BuildingWall(160, 50, -160,   50,50, 3,   0, 0, 0, txt_popcornWall, txt_BROWN_BRICK, txt_BROWN_BRICK,txt_BROWN_BRICK,txt_BROWN_BRICK,txt_BROWN_BRICK); //1st floor- Back



	NEMO4BuildingWall(208, 50, -121,   3,50, 45,   0, 0, 0, txt_BROWN_BRICK, txt_BROWN_BRICK, txt_BROWN_BRICK,txt_popcornWall,txt_BROWN_BRICK,txt_BROWN_BRICK ); //1st floor- Left
	NEMO4BuildingWall(112, 50, -121,   3,50, 45,   0, 0, 0, txt_BROWN_BRICK, txt_BROWN_BRICK, txt_popcornWall,txt_BROWN_BRICK,txt_BROWN_BRICK,txt_BROWN_BRICK ); //1st floor- Left
    
// +++++++++++++++++++ 내가 다시만든 신세대집의 조그마한 집 END
	
  
  
  
  
  

   /*
static void SmallyZIP4_2flr(
	double SmallyZIP4_2flr_lr,double SmallyZIP4_2flr_ud,double SmallyZIP4_2flr_fb,
	double SmallyZIP4_2flr_size_lr,double SmallyZIP4_2flr_size_ud,double SmallyZIP4_2flr_size_fb,
	double circangle,double elevat)
	
   SmallyZIP4_2flr(내가보는뷰에서 오른쪽(+) 왼쪽(-),공중부양(위+아래-),위치 위 멀어지는쪽(-) 아래내쪽(+) ,
   
   집 앞뒤(내 뷰에서 오른쪽 왼쪽),집 높낮이,집 양옆 길이,
   
   내쪽으로 기울임(+) 반대쪽으로기울임(-),집 뒤집어짐-기울임(+) 집뒤어짐-반대쪽으로기울임(-) );
   */
   
   
   
   
   ULTARI(50,20,0,    400,20,200,      0,0);
   //ULTARI(50,20,0,   내가보는뷰에서 양옆(가로) ,내가보는뷰에서 우리창 높이,내가보는뷰에서 위아래(세로),      0,0);

   
   

 


//**********  Draw All Houses  END  

// ****** 나무들 START 
NAMOO_A(390,60,-250,   5,3,5,      0,0,7);

NAMOO_A(280,60,-250,   3,3,3,      0,0,7);


NAMOO_A(180,60,-250,   4,3,4,      0,0,7);

NAMOO_A(70,60,-250,   4,3,4,      0,0,7);

NAMOO_A(-40,60,-250,   4,3,4,      0,0,7);

NAMOO_A(-150,60,-250,   4,3,4,      0,0,7);

NAMOO_A(-260,60,-250,   4,3,4,      0,0,7);


// ****** 나무들 END 


//NAMOO_A(내가 보는뷰:오른쪽왼쪽(-가왼쪽&+가오른쪽),내가 보는뷰:공중붕뜨는 위아래 (-가아래&+가위로),내가 보는뷰:위치 위아래 (-가 내쪽에서 멀리로(위로)&+가 내쪽으로(아래로))
//,1,1,1,0,0,7);


/*
void NAMOO_B( double NAMOO_B_lr, double NAMOO_B_ud, double NAMOO_B_fb, 
double NAMOO_B_size_lr, double NAMOO_B_size_ud, double NAMOO_B_size_fb, 
double circangle, double elevat,
double NAMOO_B_BANJI)
*/


	// 큰 나무 B START
	NAMOO_B(-400,80,0,  5,4,5,     90,0,10);
	// 큰 나무 END



	
    NEMO(350,10,100,  90,1,140,   0,0,0,txt_PoolWater); //수영장
	NEMO(350,10,-5+ (ROT/2) / 1,  90,1.3,1,   0,0,0,txt_PoolWater); //Wave Moves
	
    NEMO(80,10,100,  150,1,160,   0,0,0,txt_TCourt_F); // Tennis Court
    
	//Tennis Lines START
	NEMO(80,10,200,  150,10,5,   0,0,0,txt_Tennis_Line); //Tennis Player Front Court Line
	NEMO(80,10,0,  150,10,5,   0,0,0,txt_Tennis_Line); //Tennis Player Back Court Line
	NEMO(80,10,100,  5,10,100,   0,0,0,txt_Tennis_Line); //Tennis Court Mid Line
	NEMO(-30,10,100,  5,10,160,   0,0,0,txt_Tennis_Line); //Tennis Court Side-Left Line
 	NEMO(180,10,100,  5,10,160,   0,0,0,txt_Tennis_Line); //Tennis Court Side-Right Line
	//Tennis Lines END


	//Ping Pong Table START
    NEMO(-260,40,-80,  50,5,90,   0,0,0,txt_PPtable); //PingPong Table
	NEMO(-210,20,-160,  5,20,5,   0,0,0,txt_PPmetal); //PingPong 2시방향 Leg1
	NEMO(-210,20,0,  5,20,5,   0,0,0,txt_PPmetal); //PingPong 5시방향 Leg2
  	NEMO(-310,20,0,  5,20,5,   0,0,0,txt_PPmetal); //PingPong 7시방향 Leg2
  	NEMO(-310,20,-160,  5,20,5,   0,0,0,txt_PPmetal); //PingPong 10시방향 Leg2


	NEMO(-260,46,-80,  2,1,90,   0,0,0,txt_Tennis_Line); //PingPong Mid Line
    
	
	
	NEMO(-260,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 중앙
    NEMO(-220,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 맨 오른쪽
	NEMO(-230,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 맨 오른쪽 의 왼쪽옆
	NEMO(-240,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 맨 오른쪽 의 왼쪽옆 의 왼쪽옆
    NEMO(-280,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 중앙 바로 왼쪽 옆
    NEMO(-290,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 중앙 바로 왼쪽 옆 의 옆
    NEMO(-300,55,-80,  10,7,2,   0,0,0,txt_PPnet); //PingPong Net 중앙 바로 왼쪽 옆 의 옆 의 옆 (맨왼쪽)
	//Ping Pong Table END



	
   //NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-위로, 
   //양옆길이,두께(높낮이),위아래길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor
   
	//TV Start

   NEMO(-260,55,287,  60,35,10,   0,0,0,txt_BlackTVBackground); //TV Black Background
   //NEMO(-260,55,276,  45,25,2,   0,0,0,txt_brokenTVscreen); //TV Screen


	if(YO_TV == 0)
	{
		NEMO(-260,55,276,  45,25,2,   0,0,0,txt_brokenTVscreen); //TV Screen
	} 
	else 
	{
		NEMO(-260,55,276,  45,25,2,   0,0,0,txt_Tennis_Line); //TV Screen
	}	


	//TV End
	
	
	
	
	
	
// -----------총 BIKKE START -----------
	//BONG 바퀴모양인것---2)(A,공중부양(+위로&-아래로),앞뒤 내쪽(-)&더멀리(+),
	//기울기, 반지름크기 , 높이	
	
	
	// BIKE WHEELS START
	//원본::   BONG(-200,30,170,    0,25,10,txt_BlackTVBackground ); //BIKE WHEEL LEFT 
//	GONG(-일수록 더왼쪽+일수록오른쪽,B, -일수록 벨트에서거리멀어짐 + ROT /(*로하면빨라짐) 15(숫자낮을수록도 빨라짐),     반지름길이(공크기) ); 
//   GONG(360, 210+ ROT / 1, -122, 20); //굴뚝 연기
	
	
	BONG(-200,30,170,    0- (ROT/400) / 1,25,10,txt_BlackTVBackground ); //BIKE WHEEL LEFT 

	//A,B,C(+내쪽&-더멀리)
	BONG(-200,30,165,    0,15,20,txt_BIKE_MINT_B ); //BIKE INSIDE WHEEL LEFT 

	
	
	//원본 :: BONG(-100,30,170,    0,25,10,txt_BlackTVBackground ); //BIKE WHEEL RIGHT 
	BONG(-100,30,170,    0- (ROT/400) / 1,25,10,txt_BlackTVBackground ); //BIKE WHEEL RIGHT 

	//A,B,C(+내쪽&-더멀리)
	BONG(-100,30,165,    0,15,20,txt_BIKE_MINT_B ); //BIKE INSIDE WHEEL LEFT 

	// BIKE WHEELS END
	
	
	/*

	BONG 컵모양인것---1)NEW(앞뒤 내쪽(-)&더멀리(+), 양옆(+:오른쪾) & (-:왼쪽), 공중부양(-가위로& +가아래로 &sometims거꾸로),
	기울기, 반지름크기 , 높이
	Texture) 
	
	*/ 
	//Bike Bones START
	BONG(-175,-100,-80,    90,5,30,txt_BIKE_MINT_A ); //BIKE BONE right one
	BONG(-175,-200,-100,    90,5,45,txt_BIKE_MINT_A ); //BIKE BONE left one
	
	
//	BONG(-가왼쪽&+가오른쪽,공중부양(-아래로&+위로),-더멀리+더가까이,    -5,5,70,txt_PPnet ); 

	BONG(-185,85,165,    -5,5,70,txt_PPnet ); //BIKE손잡이
	
	

	
    NEMO(-135,80,175,  60,3,3,   0,0,0,txt_BIKE_MINT_A); //Bike 앞뒤 뼈 이어지는 중간다리
	NEMO(-100,90,175,  3,8,3,   0,0,0,txt_PPmetal); //자전거 의자밑뼈

	NEMO(-100,100,175,  20,6,15,   0,0,0,txt_BIKE_MINT_A); //자전거 의자



	//Bike Bones END

// -----------총 BIKKE END -----------
	
	
	//static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, 
	//double circangle, double circrad, double circH, 
	//unsigned int BONG_texture)

    //BONG(-가내쪽 +가 멀리,+가오른쪽&-가왼쪽, 공중부양+가아래&-가위로,    90,35,20,txt_Tennis_Line );

	//Pong Cup MOST RIGHT START
    BONG(-250,-450,-60,    90,40,20,txt_pongcup_RED );
	
	BONG(-250,-450,-80,    90,45,20,txt_pongcup_RED );
	BONG(-250,-450,-100,    90,45,20,txt_pongcup_RED );
	
	BONG(-250,-450,-120,    90,45,20,txt_pongcup_RED );
	BONG(-250,-450,-140,    90,45,20,txt_pongcup_RED );
	
	BONG(-250,-450,-160,    90,50,20,txt_pongcup_RED );
	BONG(-250,-450,-180,    90,50,20,txt_pongcup_RED );
	
	BONG(-250,-450,-181,    90,40,2, txt_Tennis_Line );
	//Pong Cup MOST RIGHT END
	

	
	
	
	//static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, 
	//double circangle, double circrad, double circH, 
	//unsigned int BONG_texture)

    //BONG(-가내쪽 +가 멀리,+가오른쪽&-가왼쪽, 공중부양+가아래&-가위로,    90,35,20,txt_Tennis_Line );

	
	//Pong Cup Left next to the Most right one START
	
	
	BONG(-250,-570,-60,    90,40,20,txt_pongcup_BLUE );
	
	BONG(-250,-570,-80,    90,45,20,txt_pongcup_BLUE );
	BONG(-250,-570,-100,    90,45,20,txt_pongcup_BLUE );
	
	BONG(-250,-570,-120,    90,45,20,txt_pongcup_BLUE );
	BONG(-250,-570,-140,    90,45,20,txt_pongcup_BLUE );
	
	BONG(-250,-570,-160,    90,50,20,txt_pongcup_BLUE );
	BONG(-250,-570,-180,    90,50,20,txt_pongcup_BLUE );
	
	BONG(-250,-570,-181,    90,40,2, txt_Tennis_Line );
	
	//Pong Cup Left next to the Most right one END
	
	



	//Pong Cup Left next to the Most LEFT one START
	
	
	BONG(-250,-700,-60,    90,40,20,txt_pongcup_RED );
	
	BONG(-250,-700,-80,    90,45,20,txt_pongcup_RED );
	BONG(-250,-700,-100,    90,45,20,txt_pongcup_RED );
	
	BONG(-250,-700,-120,    90,45,20,txt_pongcup_RED );
	BONG(-250,-700,-140,    90,45,20,txt_pongcup_RED );
	
	BONG(-250,-700,-160,    90,50,20,txt_pongcup_RED );
	BONG(-250,-700,-180,    90,50,20,txt_pongcup_RED );
	
	BONG(-250,-700,-181,    90,40,2, txt_Tennis_Line );
	
	//Pong Cup Left next to the Most LEFT one END
	








//------------- PowerRanger START

   //NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-아래쪽, 
   //양옆길이,두께(높낮이),위아래길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor





// ------------------ 내 시각: 오른발 START
 
 
    NEMO(-580, 170, -150,   20, 20 , 15,   0, 0, -30, txt_RED);//Red pant above socks	

	NEMO(-550, 110, -150,   20, 60 , 15,   0, 0, 30, txt_SOCKS);//SOCKS

    NEMO(-520, 40, -150,   40, 30, 30,   0, 0, 0, txt_CHECK); //Shoe

	
// ------------------ 내 시각: 오른발 END
	
   //NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-아래쪽, 
   //양옆길이,두께(높낮이),앞뒤길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor

// 예시:   NEMO4FACE(-500, 500, 100, 40, 40, 40,   0, 0, 0, txt_face);  // The  Face (marshmellow textured)



// ------------------ BELT & K-Flag on the BELT START 
    NEMO(-590, 220, -150,   40, 30, 30,   0, 0, 0, txt_RAINBOW);//Rainbow Belt
    GONG(-590, 220, -100.5 + ROT / 1, 30); //New ChestBall
	//	GONG(-일수록 더왼쪽+일수록오른쪽,B, -일수록 벨트에서거리멀어짐 + ROT /(*로하면빨라짐) 15(숫자낮을수록도 빨라짐),     반지름길이(공크기) ); 

	NEMO(-590, 220, -127,   20, 20, 10,   0, 0, 0, txt_K_Flag);//K-Flag on the  Belt
	

// ------------------ BELT & K-Flag on the BELT END 

// ------------------ BODY START

    NEMO(-590, 265, -150,   40, 15, 30,   0, 0, 0, txt_RED);//Bottom Body
	
	NEMO(-585, 315, -150,   70, 35, 30,   0, 0, 0, txt_RED);//Top Body
	
	
	NEMO(-585, 360, -150,   20, 15, 30,   0, 0, 0, txt_RED);//Neck
	

	
  

// ******FACE ONLY WITH ANXIETY MODE START **********
	if (anxiety_level_var >= 110)
	{
	NEMO4FACE(-650, 430, -150, 20, 20, 20,   0, 0, 0, txt_RED);
	NEMO4FACE(-650,500, -150, 20, 20, 20,   0, 0, 40, txt_RED);  
	
	NEMO4FACE(-585, 430, -150, 20, 20, 20,   40, 0, 0, txt_face);
	NEMO4FACE(-585, 500, -150, 20, 20, 20,   0, 0, 70, txt_RED);

	
	NEMO4FACE(-520, 430, -150, 20, 20, 20,   0, 0, 40, txt_RED);  
    NEMO4FACE(-520, 500, -150, 20, 20, 20,   0, 0, 110, txt_RED);


	}
	
	
	else
	{
	NEMO4FACE(-585, 430, -150, 70+PRANGER_FACE_GETBIGGER_VAL, 70+PRANGER_FACE_GETBIGGER_VAL, 70+PRANGER_FACE_GETBIGGER_VAL,   0, 0, 0, txt_face);  // The  Face (marshmellow textured)
	}
	

	NEMO(-599, 610, -150,   110, 20, 30,   0, 0, 0, txt_PPmetal); //Anxiety Frame
	NEMO(RedAnxietyLine_Original_POS+OnorOff_MovingRedAnxietyLine*(ROT/8)/1, 610, -110,   anxiety_level_var, 20, 10,   0, 0, 0, txt_pongcup_RED); //Anxiety Red Line


// ******FACE ONLY WITH ANXIETY MODE END **********

//	GONG(-일수록 더왼쪽+일수록오른쪽,B, -일수록 벨트에서거리멀어짐 + ROT /(*로하면빨라짐) 15(숫자낮을수록도 빨라짐),     반지름길이(공크기) ); 
//	NEMO(350,10,-5+ (ROT/2) / 1,  90,1.3,1,   0,0,0,txt_PoolWater); //수영장 Wave

// ------------------ BODY END






// ------------------ ARM START
		
		NEMO(-490, 315, -150,   30, 20, 30,   0, 0, 0, txt_RED);//right arm
		
	//NEMO(-가왼쪽&+가오른쪽, 공중부양-가더아래로&+가위로,+내쪽&-아래쪽, 
   //양옆길이,두께(높낮이),앞뒤길이 ,
   //double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3,
   //txt_PPnet); //Front floor infrontofdoor
   

// ****************      GREENGUN SHOOTING MODE & BUILDING START
    if(OnorOFF_Pranger_GREENGUN  == 0)
	{
		NEMO(-450, 310, -120,   10, 30, 60,   0, 0, 0, txt_CHECK);//HOLDING right Hand 1(맨왼쪽) 팔에 붙어있는것
	    NEMO(-400, 310, -120,   10, 30, 60,   0, 0, 0, txt_CHECK);//HOLDING right Hand 2(오른쪽) 팔에 붙어있는것
		
		NEMO(-420, 310, -190,   35, 30, 10,   0, 0, 0, txt_CHECK);//HOLDING right Hand 3 중간 연결판막 

		NEMO(-420, 310, -120,   12, 50, 20,   0, 0, 0, txt_grey);//GUN 손잡이
		
		NEMO(-400, 380, -120,   60, 20, 20,   0, 0, 0, txt_grey);//GUN 1 탑 건 그레이
	    NEMO(-320, 380, -120,   20, 10, 10,   0, 0, 0, txt_brokenTVscreen);//GUN 2 형광막대기
	    NEMO(-300+ (ROT*8), 380, -120,   5, 5, 5,   0, 0, 0, txt_brokenTVscreen);//GUN 3 형광총알
//	    NEMO(-300+ (ROT/2)/1, 380, -120,   5, 5, 5,   0, 0, 0, txt_brokenTVscreen);//GUN 3 형광총알

		//	GONG(-일수록 더왼쪽+일수록오른쪽,B, -일수록 벨트에서거리멀어짐 + ROT /(*로하면빨라짐) 15(숫자낮을수록도 빨라짐),     반지름길이(공크기) ); 
		//	NEMO(RedAnxietyLine_Original_POS+OnorOff_MovingRedAnxietyLine*(ROT/8)/1,
		//   GONG(360, 210+ ROT / 1, -122, 20); //굴뚝 연기
		
	
		
	//1st floor START
	NEMO(-40, 10, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 


	NEMO4BuildingWall(-40, 77, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 77, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right

	//1st floor END




	//2nd floor START
	NEMO(-40, 145, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 210, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 210, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right


	//2nd floor END



	//3rd floor START
OnorOFf_4_BuildingBreak_ROT_IDLE = 1;
	
	NEMO(-40, 280, -130,    80- (BuildingBreak_ROT/8),3- (BuildingBreak_ROT/8), 50- (BuildingBreak_ROT/8),   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 343, -77,   80- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 3- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 343, -183,   80- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 3-(BuildingBreak_ROT/8),   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 343, -131,   3- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 55- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 343, -131,   3- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 55- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right


	//3rd floor END

	//4th floor START


	NEMO(-40, 415, -130,    80- (BuildingBreak_ROT/8),3- (BuildingBreak_ROT/8), 50- (BuildingBreak_ROT/8),   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 476, -77,   80- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 3- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 476, -183,   80- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 3- (BuildingBreak_ROT/8),   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 476, -131,   3- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 55- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 476, -131,   3- (BuildingBreak_ROT/8),70- (BuildingBreak_ROT/8), 55- (BuildingBreak_ROT/8),   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right

	//4th floor END

	NEMO(-40, 550, -130,    80- (BuildingBreak_ROT/8),3- (BuildingBreak_ROT/8), 50- (BuildingBreak_ROT/8),   0, 0, 0, txt_bochoong_wall); //꼭대기 천장 

	
	
	
	} 
	else 
	{
	OnorOFf_4_BuildingBreak_ROT_IDLE = 0;
		
	NEMO(-430, 315, -150,   30, 40, 50,   0, 0, 0, txt_CHECK);//NOTHING HOLDING right Hand

	//1st floor START
	NEMO(-40, 10, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 


	NEMO4BuildingWall(-40, 77, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 77, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right

	//1st floor END




	//2nd floor START
	NEMO(-40, 145, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 210, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 210, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right


	//2nd floor END

	//3rd floor START


	NEMO(-40, 280, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 343, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 343, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 343, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 343, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right


	//3rd floor END

	//4th floor START


	NEMO(-40, 415, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 

	NEMO4BuildingWall(-40, 476, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

	NEMO4BuildingWall(-40, 476, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


	NEMO4BuildingWall(-120, 476, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
	NEMO4BuildingWall(40, 476, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right

	//4th floor END

	NEMO(-40, 550, -130,    80,3, 50,   0, 0, 0, txt_bochoong_wall); //꼭대기 천장 


    }	   
   
// ****************      GREENGUN SHOOTING MODE & BUILDING END






//**************    내가만든 새로운 빌딩 START 

//층마다 바닥카펫 공중부양:135씩증가
//층건물 앞뒤옆밑 총 : 133씩증가

//1st floor START
NEMO(-40, 10, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 


NEMO4BuildingWall(-40, 77, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

NEMO4BuildingWall(-40, 77, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


NEMO4BuildingWall(-120, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
NEMO4BuildingWall(40, 77, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right

//1st floor END




//2nd floor START
NEMO(-40, 145, -130,    80,3, 50,   0, 0, 0, txt_FLOOR); 

NEMO4BuildingWall(-40, 210, -77,   80,70, 3,   0, 0, 0, txt_buildingwindow, txt_FLOOR, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Front

NEMO4BuildingWall(-40, 210, -183,   80,70, 3,   0, 0, 0, txt_FLOOR, txt_buildingwindow, txt_buildingwindow,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow); //1st floor- Back


NEMO4BuildingWall(-120, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_FLOOR,txt_buildingwindow,txt_buildingwindow,txt_buildingwindow ); //1st floor- Left
NEMO4BuildingWall(40, 210, -131,   3,70, 55,   0, 0, 0, txt_buildingwindow, txt_buildingwindow, txt_buildingwindow,txt_FLOOR,txt_buildingwindow,txt_buildingwindow ); //1st floor- right


//2nd floor END



//**************    내가만든 새로운 빌딩 END 
   
		
		
		

		
		
// -------------------- LEFT ARM START		
		NEMO(-680, 315, -150,   30, 20, 30,   0, 0, 0, txt_RED);//left arm
		NEMO(-740, 315, -150,   30, 40, 50,   0, 0, 0, txt_CHECK);//left Hand
// -------------------- LEFT ARM END		

// ------------------ ARM END




// ------------------ 내 시각: 왼발 START



    NEMO(-600, 170, -150,   20, 20 , 15,   0, 0, -30, txt_RED);//Red pant above socks	

    NEMO(-630, 110, -150,   20, 60 , 15,   0, 0, -30, txt_SOCKS);//SOCKS
    
	//오른발예시:    NEMO(-520, 40, -150,   40, 30, 30,   0, 0, 0, txt_CHECK); //Shoe
    NEMO(-660, 40, -150,   40, 30, 30,   0, 0, 0, txt_CHECK);//Shoe 

// ------------------ 내 시각: 왼발 END






//------------- New PowerRanger END in 







   if (chook)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(chook_len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,chook_len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,chook_len);
      glEnd();
	  
	  
	  
	  
      glRasterPos3d(chook_len,0.0,0.0);
      characprint("X");
      glRasterPos3d(0.0,chook_len,0.0);
      characprint("Y");
      glRasterPos3d(0.0,0.0,chook_len);
      characprint("Z");
   }
   
   
   
   glWindowPos2i(5,5);
   //characprint("Angle=%d,%d  Dim=%.1f FOV=%d ",circangle,elevat,worldsize,perspective_view,orth_per_fp_view == 1 ?"FPN": (orth_per_fp_view == 2? "Perpective":"Orthogonal"));
   characprint("Angle=%d,%d  Dim=%.1f FOV=%d Projection=%s Light=%s",circangle,elevat,worldsize,perspective_view,orth_per_fp_view?"Perpective":"Orthogonal",LIGHT?"On":"Off"); 

   if (LIGHT) 
   { 
      glWindowPos2i(5,45); 
      characprint("Model=%s LocalViewer=%s Distance=%d Elevation=%.1f",sm_flat_shading?"Smooth":"Flat",LocalVIEWER_M?"On":"Off",DofLight,Light_elevat); 
      glWindowPos2i(5,25); 
      characprint("Ambient=%d  Diffuse=%d Specular=%d Emission=%d Shininess=%.0f",AMB,diffuse,SPEC,EMIS,SHIN_Y); 
   } 
   
   CheckError("display");
   glFlush();
   glutSwapBuffers();
}





void special_hotkey(int hotkey_press,int hotkey_x,int hotkey_y)
{
	
   if (hotkey_press == GLUT_KEY_RIGHT)
   {
      circangle -= 5;
   }
   else if (hotkey_press == GLUT_KEY_LEFT)
   {
      circangle += 5;
   }
   else if (hotkey_press == GLUT_KEY_UP)
   {
      elevat += 5;
   }
   else if (hotkey_press == GLUT_KEY_DOWN)
   {
      elevat -= 5;
   }
   else if (hotkey_press == GLUT_KEY_PAGE_DOWN)
   {
      worldsize += 5; 
   }
   else if (hotkey_press == GLUT_KEY_PAGE_UP && worldsize>1)
   {
      worldsize -= 5; 
   }
   else if (hotkey_press == GLUT_KEY_F1)  
   { 
      sm_flat_shading = 1-sm_flat_shading;  
   } 
   else if (hotkey_press == GLUT_KEY_F2)  
   {
      LocalVIEWER_M = 1-LocalVIEWER_M;  
   }

   else if (hotkey_press == GLUT_KEY_F8) 
   {
      BallInc = (BallInc==10)?3:10; 
   }
   else if (hotkey_press == GLUT_KEY_F9) 
   {
      UV = -UV; 
   }
  
 
  
  
  
  
   circangle %= 360;
   elevat %= 360;
   circangle_CAM_V %= 360;
   elevat_CAM_V %= 360;
   
   

   
   if(orth_per_fp_view == 0)
		PROJECTION(0,widnheight_ratio,worldsize);
   else
	   PROJECTION(perspective_view,widnheight_ratio,worldsize);
   
   
   glutPostRedisplay();
}


void hotkey_press_func(unsigned char hotkey_press_func_ch,int hk_press_x,int hk_press_y) 
{ 

   
	
   if (hotkey_press_func_ch == 27)
   {
      exit(0);
   }
   else if (hotkey_press_func_ch == '0')
   {
	   circangle = -25;
       elevat = 35;
	   perspective_view=80;
	   worldsize=440;
   }
   else if (hotkey_press_func_ch == 'a' || hotkey_press_func_ch == 'A')
   {
	   if (anxiety_level_var >= 110)
	   {
	   }
	   else
	   {
	   OnorOff_MovingRedAnxietyLine = 0;
	   RedAnxietyLine_Original_POS = -600;
	   anxiety_level_var = anxiety_level_var+10;
	   PRANGER_FACE_GETBIGGER_VAL = PRANGER_FACE_GETBIGGER_VAL +5;
	   }
   }

   else if (hotkey_press_func_ch == 'd' || hotkey_press_func_ch =='D')
   {
	   YO_MAINGATE = 1- YO_MAINGATE;
   }
   else if (hotkey_press_func_ch == 'l' || hotkey_press_func_ch == 'L') 
   {
      LIGHT = 1-LIGHT; 
   }
   else if (hotkey_press_func_ch == 'm' || hotkey_press_func_ch == 'M')
   {
      orth_per_fp_view = 1-orth_per_fp_view;
   }
   else if (hotkey_press_func_ch == 'z' || hotkey_press_func_ch == 'Z') 
   {
      MovOfLight = 1-MovOfLight; 
   }
   else if (hotkey_press_func_ch=='q' && AMB>0) 
   {
      AMB -= 5;
   }
   else if (hotkey_press_func_ch=='Q' && AMB<100) 
   {
      AMB += 5; 
   }
   else if (hotkey_press_func_ch=='w' && diffuse>0) 
   {
      diffuse -= 5;
   }
   else if (hotkey_press_func_ch=='W' && diffuse<100) 
   {
      diffuse += 5; 
   }
   else if (hotkey_press_func_ch=='r' && SPEC>0) 
   {
      SPEC -= 5; 
   }
   else if (hotkey_press_func_ch=='R' && SPEC<100)
   {
      SPEC += 5; 
   }
   else if (hotkey_press_func_ch=='e' && EMIS>0) 
   {
      EMIS -= 5; 
   }
   else if (hotkey_press_func_ch=='E' && EMIS<100) 
   {
      EMIS += 5; 
   }
   else if (hotkey_press_func_ch=='t' && SHINE_L>-1) 
   {
      SHINE_L -= 1; 
   }
   else if (hotkey_press_func_ch=='T' && SHINE_L<7)
   {
      SHINE_L += 1; 
   }
   else if (hotkey_press_func_ch == 'g' || hotkey_press_func_ch == 'G') 
   {
	   OnorOFF_Pranger_GREENGUN = 1 - OnorOFF_Pranger_GREENGUN;
   }
   else if (hotkey_press_func_ch == 'k' || hotkey_press_func_ch =='K')
   {
	   YO_TV = 1- YO_TV;
   } 



   
 
   
   
   
 
   SHINE_VAL[0] = SHINE_L<0 ? 0 : pow(2.0,SHINE_L);
   SHIN_Y = SHINE_L<0 ? 0 : pow(2.0,SHINE_L); 
   
   
   
   if(orth_per_fp_view == 0)
		PROJECTION(0,widnheight_ratio,worldsize);
   else
	   PROJECTION(perspective_view,widnheight_ratio,worldsize);
   
   //   PROJECTION(orth_per_fp_view?perspective_view:0,widnheight_ratio,worldsize); 
   glutIdleFunc(MovOfLight?idle:NULL);

   
   glutPostRedisplay();
}




void shapeRedraw(int width,int height)
{
   widnheight_ratio = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   
   if(orth_per_fp_view == 0)
		PROJECTION(0,widnheight_ratio,worldsize);
   else
	   PROJECTION(perspective_view,widnheight_ratio,worldsize);
}

int main(int argumentA,char* argumentB[])
{
   
    OnorOFf_4_BuildingBreak_ROT_IDLE = 1;

	glutInit(&argumentA,argumentB);
	glutInitWindowSize(1060,850);
	glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow("Junwoo Jang - CSCI 5229 - Final Project");
    glutIdleFunc(idle);   
	
	
#ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal("Error initializing GLEW\n");
#endif


   glutDisplayFunc(draw_scene);
   glutReshapeFunc(shapeRedraw); 
   glutSpecialFunc(special_hotkey); 
   glutKeyboardFunc(hotkey_press_func); 
   

  
   
   CheckError("init"); 
   glutMainLoop();
   return 0;
}
