
1.
The Makefile will build the program for the user by typing "make" on the command prompt.

2.
After type "make" on the command, you can type "./final.exe" to execute the program.


	This Program displays a beautiful neighborhood that has
	houses, a tall building, a tennis court, a swimming pool, a powerranger playing
	beer pong, etc.
	
	***** I think this is one of the interesting/creative things 
	that I am Proud Of by pressing the Keys *****:
	
	1) The PowerRanger gets anxious and the anxious level goes up by pressing
	'a' or 'A' which ends up exploding the powerranger's head.
	
	2) 'g' or 'G' will change the shape of powerranger's hand and it will  hold the gun which will shoot the building.
	The building will start to break down.
	
	
	*******Hot Keys*******
	
	ESC: Exit Program
	0: Original(Reset) view with original angle
	l/L: Toggle the lighting
	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles
	
	Q/q: Increase/Decrease the ambient light
	W/w: Increase/Decrease the diffuse light
	E/e: Increase/Decrease the emitted light
	R/r: Increase/Decrease the specular light
	T/t: Increase/Decrease the shininess
	
	a/A: The more you push this button, the more it makes PowerRanger Anxious
	g/G: PowerRanger gun mode On and OFF: shooting the tall building next to it and the building starts to break down
	d/D: The main door(/gate) open & close
	k/K: TV On & OFF
	
	
	
	
	F1: Toggle the smooth/flat shading
	F2: Toggle the local viewer mode
	F8: Change the  increment
	F9: Invert thebottom normal
	

	z/Z: Toggle the light movement