
/*
	Junwoo Jang - CS 5229 - HW6
	Got few ideas from examples, Youtube, and my Brain
	
	This Program displays Wonderful Twin Red Power Rangers(with awesome textures on)
	with a cute bazooka gun on his head(with a beautifult texture on)	
	and beautiful cylinders.(with a beautiful check texture on)
	And You can view this with two different views: Orthogonal, Perpective
	And you can enjoy it with lights.
	And you can toggle the texture mode
	
	*******Hot Keys*******
	ESC: Exit Program
	0: Original(Reset) view with original angle
	l: Toggle the lighting
	
	
	PageUp/PageDown: Zoom in & out
	↑↓→←: View in different angles


	Q/q: Increase/Decrease the ambient light
	W/w: Increase/Decrease the diffuse light
	E/e: Increase/Decrease the emitted light
	R/r: Increase/Decrease the specular light
	S/s: Increase/Decrease the shininess



	F1: Toggle the smooth/flat shading
	F2: Toggle the local viewer mode
	F3: Toggle the light distance (1/5) 
	F8: Change the ball increment
	F9: Invert the bottom normal


	*,/: Controlling the Light Distance:Increase, Decrease   
	],[: Rise,Lower the light 
	+/-: Change field of view


	m/M: Switch View Modes(→Orthogonal View→Perpective View→)
	p/P: Hide PowerRangers & Show PowerRangersxes
	b/B: Hide Rainbow & Show RainBow 
 

	x/X: Hide Axes & Show Axes
	z/Z: Toggle the light movement
    t/T:Change Texture mode
    o/O:Modify repeatness

*/


//Header files
#include <math.h> //standard library  for basic mathematical operations
#include <stdlib.h> //handles memory allocation, process control, conversions and others
#include <stdarg.h> //for  indefinite number of argument
#include <stdio.h> //for input and output
#include <string.h> 
//for OpenGL 
#ifdef USEGLEW 
#include <GL/glew.h> 
#endif 
#define GL_GLEXT_PROTOTYPES 
#ifdef __APPLE__ 
#include <GLUT/glut.h> 
#else 
#include <GL/glut.h> 
#endif 

#include "CSCIx229.h"


int circangle=0; //Azimuth when viewing angle         
int elevat=0; //Elevation when viewing angle 
double ROT=0; //For the Rotation
int chook=1; //Axes       
int YOpower_ranger = 1; //Variable for showingnhiding PowerRangers 
int RainBow = 1; //Variable for showingnhiding RainBow


int TXTURE_MODE=0;       
int YO_TXTURE=0;      

int orth_per_fp_view=1; //Variable for view mode: orthogonal, perspective
int perspective_view=55; // For perspective view
int MovOfLight=1; //For the movement of the light
int LIGHT=1;      // for the light
int UV=1; //for the unit value
double DofLight= 5;  // For the distance of the light


double widnheight_ratio=1;      
double worldsize=3.0;     


int BallInc=10;  
int sm_flat_shading=1;  
int LocalVIEWER_M=0;  
int EMIS=0; 
int AMB=30; 
int diffuse=100;  
int SPEC=0;  
int SHINE_L=0;  
float SHIN_Y=1;  
float Light_elevat=0;  

double REPETITION=1;  



#define LEN 8192 

//To print out
void characprint(const char* format , ...)
{
   char    chprint[LEN]; //Set length(8192) for the characters
   char*   ch=chprint;
   va_list args;
   va_start(args,format);
   vsnprintf(chprint,LEN,format,args);
   va_end(args);
   
   //  Display chracters
   while (*ch)
      glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,*ch++);
}


// To use GLUT, this function is necessary
void Fatal4gl(const char* format , ...)
{
   va_list args;
   va_start(args,format);
   vfprintf(stderr,format,args);
   va_end(args);
   exit(1);
}

//For Projection Views
void PROJECTION(double perspective_view,double widnheight_ratio,double worldsize) 
{ 
  
   glMatrixMode(GL_PROJECTION); 
   glLoadIdentity(); 

   if (perspective_view) 
   {
      gluPerspective(perspective_view,widnheight_ratio,worldsize/16,16*worldsize); 
   }
	//For Orthogonal view mode
   else 
   {
      glOrtho(-widnheight_ratio*worldsize,widnheight_ratio*worldsize,-worldsize,+worldsize,-worldsize,+worldsize); 
   }
  
   glMatrixMode(GL_MODELVIEW); 
   glLoadIdentity(); 
}


//Good to include to check error
void CheckError(const char* where) 
{ 
   int err = glGetError(); 
   if (err) fprintf(stderr,"ERROR: %s [%s]\n",gluErrorString(err),where); 
} 


static void Vertex(double circangle,double elevat)
{
   double vertex_x = Sin(circangle)*Cos(elevat); 
   double vertex_y = Cos(circangle)*Cos(elevat); 
   double vertex_z = Sin(elevat); 
   
   glNormal3d(vertex_x,vertex_y,vertex_z); 
   //glColor3f(Cos(circangle)*Cos(circangle), Sin(elevat)*Sin(elevat), Sin(circangle)*Sin(circangle)); //For the beautiful rainbow ball
   glVertex3d(vertex_x,vertex_y,vertex_z); 
   
}



static void BONG(double BONG_lr, double BONG_ud, double BONG_fb, double circangle, double circrad, double circH, unsigned int BONG_texture)
{
    double BONG_ang = 0.0;
    double BONG_s = 0.1;
    
	
   float BONG_white[] = {1,1,1,1};
   float BONG_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,BONG_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,BONG_emis); 
    
   glPushMatrix();
    
   glRotatef(circangle, 0, 1, 0); //To Rotate
   glRotatef(circangle, 1, 0, 0); //To Rotate
   glTranslated(BONG_lr,BONG_ud,BONG_fb);
	   
	   
   //  To use textures (enabling)
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,BONG_texture); 
	
	

    if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_QUAD_STRIP);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , circH);
		glTexCoord2f(REPETITION,0);
        glVertex3f(BONG_lr, BONG_ud , 0.0);
		
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,REPETITION);
    glVertex3f(circrad, 0.0, circH);
	glTexCoord2f(0,REPETITION);
    glVertex3f(circrad, 0.0, 0.0);
    glEnd();
    
	
	
    // For the Lid(top circle)
	if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , circH);
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,0);
    glVertex3f(circrad, 0.0, circH);
    glEnd();
    
	
	
    // For the bottom circle
	if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,BONG_texture); 
    glBegin(GL_POLYGON);
    BONG_ang = 0.0;
    while( BONG_ang < 2*3.1415927 ) {
        BONG_lr = circrad * cos(BONG_ang);
        BONG_ud = circrad * sin(BONG_ang);
		glTexCoord2f(0,0);
        glVertex3f(BONG_lr, BONG_ud , 0);
        BONG_ang = BONG_ang + BONG_s;
    }
	glTexCoord2f(REPETITION,0);
    glVertex3f(circrad, 0.0, circH);
    glEnd();
  
    glPopMatrix();
	glDisable(GL_TEXTURE_2D); 

    
}


//Drawing a Cube (to draw PowerRangers) 
//lr:left,right(x), ud:updown(y), fb:frontback(z), size: for dimension, col:for color, rot:for rotation
static void NEMO (double NEMO_lr,double NEMO_ud,double NEMO_fb, 
                 double NEMO_size_lr,double NEMO_size_ud,double NEMO_size_fb,
                 double NEMO_rot_1, double NEMO_rot_2, double NEMO_rot_3, 
				 unsigned int NEMO_txture)
{
	
   float NEMO_white[] = {1,1,1,1}; 
   float NEMO_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO_emis); 
   
   
   glPushMatrix();
   glTranslated(NEMO_lr,NEMO_ud,NEMO_fb);
   glRotated(NEMO_rot_1,1,0,0);
   glRotated(NEMO_rot_1,0,1,0);
   glRotated(NEMO_rot_3,0,0,1);
   glScaled(NEMO_size_lr,NEMO_size_ud,NEMO_size_fb);
  
   //  To use textures (enabling)
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO_txture); 




   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS);
   glNormal3f(0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1, 1);
   glEnd();
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 0, -1); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glEnd(); 
   
   
   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glTexCoord2f(0,REPETITION); glVertex3f(+1,+1,+1);  
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(-1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd();
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 1, 0);  
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,+1,+1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd(); 
   



   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO_txture); 
   glBegin(GL_QUADS); 
   glNormal3f( 0, -1, 0);
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,-1,+1);
   
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D); 

}

static void NEMO4FACE(double NEMO4FACE_lr,double NEMO4FACE_ud,double NEMO4FACE_fb, 
                 double NEMO4FACE_size_lr,double NEMO4FACE_size_ud,double NEMO4FACE_size_fb,
                 double NEMO4FACE_rot_1, double NEMO4FACE_rot_2, double NEMO4FACE_rot_3, 
				 unsigned int NEMO4FACE_txture)
{
	
   unsigned int NEMO4FACE_txture_rest = LoadTexBMP("txt_redsuit.bmp");
   
   float NEMO4FACE_white[] = {1,1,1,1}; 
   float NEMO4FACE_emis[]  = {0.0,0.0,0.01*EMIS,1.0}; 
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,NEMO4FACE_white); 
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,NEMO4FACE_emis); 
   
   
   glPushMatrix();
   glTranslated(NEMO4FACE_lr,NEMO4FACE_ud,NEMO4FACE_fb);
   glRotated(NEMO4FACE_rot_1,1,0,0);
   glRotated(NEMO4FACE_rot_1,0,1,0);
   glRotated(NEMO4FACE_rot_3,0,0,1);
   glScaled(NEMO4FACE_size_lr,NEMO4FACE_size_ud,NEMO4FACE_size_fb);
  
 
   //  To use textures (enabling) for the FACE
   glEnable(GL_TEXTURE_2D); 
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture); 
   
   //The front face
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture);
   glBegin(GL_QUADS);
   glNormal3f(0, 0, 1);
   glTexCoord2f(0,0); glVertex3f(-1,-1, 1);
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1, 1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1, 1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1, 1);
   glEnd();
   

   //  To use textures (enabling) for the rest(not to duplicat the cover everywhere on the cube)
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE); 
   glColor3f(1,1,1); 
   glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   
   //The Rest parts except the front
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 0, -1); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1);
   glEnd(); 
   
   

   
   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f( 1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(+1,-1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(+1,+1,+1);  
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(-1, 0, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1);
   glTexCoord2f(REPETITION,0); glVertex3f(-1,-1,+1);
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(-1,+1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1); 
   glEnd();
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f(0, 1, 0);  
   glTexCoord2f(0,0); glVertex3f(-1,+1,+1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,+1,+1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,+1,-1); 
   glTexCoord2f(0,REPETITION); glVertex3f(-1,+1,-1);
   glEnd(); 
   
   

   if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,NEMO4FACE_txture_rest); 
   glBegin(GL_QUADS); 
   glNormal3f( 0, -1, 0); 
   glTexCoord2f(0,0); glVertex3f(-1,-1,-1); 
   glTexCoord2f(REPETITION,0); glVertex3f(+1,-1,-1); 
   glTexCoord2f(REPETITION,REPETITION); glVertex3f(+1,-1,+1);
   glTexCoord2f(0,REPETITION); glVertex3f(-1,-1,+1);
   
   
   glEnd();
   glPopMatrix();
   glDisable(GL_TEXTURE_2D);

}

static void PowerRanger(double PR_lr, double PR_ud, double PR_fb, double PR_ds, double PR_rot_K, double PR_rot_O, double PR_rot_R)
{
    
	unsigned int txt_face = LoadTexBMP("txt_face.bmp");
	unsigned int txt_RED = LoadTexBMP("txt_redsuit.bmp");
	unsigned int txt_CHECK = LoadTexBMP("txt_check.bmp");
	unsigned int txt_SOCKS = LoadTexBMP("txt_socks.bmp");
	unsigned int txt_RAINBOW = LoadTexBMP("txt_rainbow.bmp");
	unsigned int txt_K_Flag = LoadTexBMP("txt_k_flag.bmp");
	unsigned int txt_SHOOT = LoadTexBMP("txt_shoots.bmp");
	unsigned int txt_PINK = LoadTexBMP("txt_pink.bmp");
	unsigned int txt_GREY = LoadTexBMP("txt_grey.bmp");

   
    glPushMatrix();

    glTranslated(PR_lr, PR_ud, PR_fb);
    glRotated(PR_rot_K, 1, 0, 0);
    glRotated(PR_rot_O, 0, 1, 0);
    glRotated(PR_rot_R, 0, 0, 1);
    glScaled(PR_ds, PR_ds, PR_ds);
	


    NEMO4FACE(0, 0.6, 0, 0.4, 0.3, 0.4, 0, 0, 0, txt_face);  // The  Face (marshmellow textured)
		  
    NEMO(0, 1.1, -0.03, 0.47, 0.13, 0.47,0, 0, 0, txt_RAINBOW);   // The rainbow hat textured 
    
	
	NEMO(0, 1.3, -0.06, 0.36, 0.1, 0.36,0, 0, 0, txt_RED); 
    NEMO(0, 1.22, 0.4, 0.1, 0.1, 0.1,0, 0, 0, txt_RED);
	
	//Right ear ish
    NEMO(0, 1.32, -0.46, 0.1, 0.1, 0.1,0, 0, 0, txt_RED); 	 
    NEMO(0, 1.16, -0.56, 0.1, 0.1, 0.1,0, 0, 0, txt_RED); 	 
    NEMO(0.5, 0.6, 0, 0.07, 0.45, 0.45,0, 0, 0, txt_RED); 	 
	
	//Left Ear ish
    NEMO(0.6, 0.6, -0.1, 0.07, 0.2, 0.2,0, 0, 0, txt_RED);	
    NEMO(-0.5, 0.6, 0, 0.07, 0.45, 0.45,0, 0, 0, txt_RED); 	 
    NEMO(-0.6, 0.6, -0.1, 0.07, 0.2, 0.2,0, 0, 0, txt_RED); 

    //Back head	
    NEMO(0, 0.6, -0.5, 0.45, 0.45, 0.07,0, 0, 0, txt_RED); 	 
    NEMO(0, 0.6, -0.6, 0.4, 0.4, 0.07,0, 0, 0, txt_RED);  
    NEMO(0, 0.6, -0.7, 0.3, 0.3, 0.07,0, 0, 0, txt_RED); 
	

	BONG(0, 1.5, -0.4, -0.58, 0.2, 1.3,txt_PINK ); //For the bazooka gun
	

    NEMO(0, 0.2, 0, 0.9, 0.09, 0.1,0, 0, 0, txt_RED);  // Shoulder Pad

    NEMO(0, 0, 0, 0.25, 0.2, 0.15,0, 0, 0, txt_RED); //BODY	 
    NEMO(0, -0.27, 0, 0.19, 0.07, 0.1,0, 0, 0, txt_RED); 

    NEMO(0.54, 0.02, 0, 0.3, 0.08, 0.08,0, 0, 0, txt_RED);  //Left Arm() 
    NEMO(0.85, 0.02, 0, 0.1, 0.15, 0.15,0, 0, 0, txt_CHECK);  //Left Arm-Hand()
    NEMO(1.36, 0.3, 0, 0.4, 0.1, 0.15,0, 0, 0, txt_PINK);  // Laser Gun
    NEMO(1.8, 0.3, 0, 0.2, 0.05, 0.15,0, 0, 0, txt_GREY);  //  Silencer
	NEMO(2.2, 0.3, 0, 0.04, 0.02, 0.15,0, 0, 0, txt_SHOOT);  // The Laser Bim1
	NEMO(2.4, 0.3, 0, 0.04, 0.02, 0.15,0, 0, 0, txt_SHOOT);  // The Laser Bim2	
	NEMO(2.6, 0.3, 0, 0.04, 0.02, 0.15,0, 0, 0, txt_SHOOT);  // The Laser Bim3
    NEMO(1.0, 0.05, 0, 0.1, 0.15, 0.15,0, 0, 0, txt_PINK);  //Gun Handle

	
	NEMO(-0.32, 0.02, 0, 0.3, 0.08, 0.08,0, 0, 0, txt_RED);  //Right Arm()	
    NEMO(-0.63, 0.02, 0, 0.1, 0.15, 0.15,0, 0, 0, txt_CHECK);  //Right Arm-Hand()

		 
    NEMO(0, -0.4, 0, 0.2, 0.08, 0.12, 0, 0, 0, txt_RAINBOW); //Belt()
    NEMO(0, -0.4, 0.011, 0.1, 0.05, 0.13, 0, 0, 0, txt_K_Flag); //Belt Label()  
		  
    NEMO(0.15, -0.6, 0, 0.1, 0.12, 0.08, 0, 0, 25, txt_RED); //Left Leg 
    NEMO(0.25, -0.8, 0, 0.1, 0.12, 0.08, 0, 0, 25, txt_SOCKS);  
    NEMO(0.3, -0.9, 0, 0.1, 0.12, 0.08,0, 0, 25, txt_SOCKS); 	 
    NEMO(0.41, -1.1, 0, 0.25, 0.12, 0.2, 0, 0, 25, txt_CHECK); //Shoe
		    
    NEMO(-0.15, -0.6, 0, 0.1, 0.12, 0.08, 0, 0, -25, txt_RED); //Right Leg  
    NEMO(-0.25, -0.8, 0, 0.1, 0.12, 0.08, 0, 0, -25, txt_SOCKS); 
    NEMO(-0.3, -0.9, 0, 0.1, 0.12, 0.08,0, 0, -25, txt_SOCKS); 
    NEMO(-0.41, -1.1, 0, 0.25, 0.12, 0.2, 0, 0, -25, txt_CHECK); //Shoe 


		 
    glPopMatrix();
}




static void ball(double BALL_x,double BALL_y,double BALL_z,double BALL_r) 
{
	
	unsigned int txt_PURPLE = LoadTexBMP("txt_purp.bmp");
    int BALL_circangle,BALL_elevat; 
 
   
   float BALL_white[] = {1,1,1,1};
   float BALL_Emission[]  = {0.0,0.0,0.01*EMIS,1.0};
   glMaterialf(GL_FRONT_AND_BACK,GL_SHININESS,SHIN_Y);
   glMaterialfv(GL_FRONT_AND_BACK,GL_SPECULAR,BALL_white);
   glMaterialfv(GL_FRONT_AND_BACK,GL_EMISSION,BALL_Emission);
   
   
   glPushMatrix(); 
   glTranslated(BALL_x,BALL_y,BALL_z); 
   glScaled(BALL_r,BALL_r,BALL_r); 
   

   //  To use textures (enabling)
   glEnable(GL_TEXTURE_2D);
   glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,TXTURE_MODE?GL_REPLACE:GL_MODULATE);
   glColor3f(1,1,1);
   glBindTexture(GL_TEXTURE_2D,txt_PURPLE);


   for (BALL_elevat=-90;BALL_elevat<90;BALL_elevat+=BallInc) 
   {
	  if (YO_TXTURE) glBindTexture(GL_TEXTURE_2D,txt_PURPLE);

		glBegin(GL_QUAD_STRIP); 
      for (BALL_circangle=0;BALL_circangle<=360;BALL_circangle+=2*BallInc) 
      {
		 glTexCoord2f(0,0);
         Vertex(BALL_circangle,BALL_elevat); 
		 glTexCoord2f(REPETITION,0);
         Vertex(BALL_circangle,BALL_elevat+BallInc); 

      } 
      glEnd(); 
   } 
   
    glPopMatrix(); 
    glDisable(GL_TEXTURE_2D); 
} 




//For the scene(background)
void draw_scene()
{
   const double chook_len=1.5;  //Axes' Length
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
   glEnable(GL_DEPTH_TEST);
   glLoadIdentity();
   
   unsigned int txt_SOCKS = LoadTexBMP("txt_socks.bmp");

   //For the View modes
   if (orth_per_fp_view)
   {
	  double BIGeye_x = -2*worldsize*Sin(circangle)*Cos(elevat); 
      double BIGeye_y = +2*worldsize        *Sin(elevat); 
      double BIGeye_z = +2*worldsize*Cos(circangle)*Cos(elevat); 

      gluLookAt(BIGeye_x,BIGeye_y,BIGeye_z,0,0,0,0,Cos(elevat),0); 
   }
   else 
   { 
      glRotatef(elevat,1,0,0); 
      glRotatef(circangle,0,1,0); 
   } 
   
    glShadeModel(sm_flat_shading ? GL_SMOOTH : GL_FLAT); 
 
   if (LIGHT) 
   { 
        
        float LIGHT_amb[]   = {0.01*AMB ,0.01*AMB ,0.01*AMB ,1.0}; 
        float LIGHT_Diffuse[]   = {0.01*diffuse ,0.01*diffuse ,0.01*diffuse ,1.0}; 
        float LIGHT_SPEC[]  = {0.01*SPEC,0.01*SPEC,0.01*SPEC,1.0}; 
        float LIGHT_Pos[]  = {DofLight*Cos(ROT),Light_elevat,DofLight*Sin(ROT),1.0}; 
        
		glColor3f(1,1,1); 
        ball(LIGHT_Pos[0],LIGHT_Pos[1],LIGHT_Pos[2] , 0.1); 
        glEnable(GL_NORMALIZE); 
        glEnable(GL_LIGHTING); 
        glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER,LocalVIEWER_M); 
        glColorMaterial(GL_FRONT_AND_BACK,GL_AMBIENT_AND_DIFFUSE); 
        glEnable(GL_COLOR_MATERIAL); 
        glEnable(GL_LIGHT0); 
        glLightfv(GL_LIGHT0,GL_AMBIENT ,LIGHT_amb); 
        glLightfv(GL_LIGHT0,GL_DIFFUSE ,LIGHT_Diffuse); 
        glLightfv(GL_LIGHT0,GL_SPECULAR,LIGHT_SPEC); 
        glLightfv(GL_LIGHT0,GL_POSITION,LIGHT_Pos); 
   }
   else  
   {
     glDisable(GL_LIGHTING);  
   }
   


//3D Objects
   if (YOpower_ranger) 
   { 
      PowerRanger(-2.3, 0.98, -0.5, 0.6, 0, 45, 0); //PowerRanger1
      PowerRanger(0.8, 1, -1.2, 0.6, 0, 0, 0); //PowerRanger2
   }

   if (RainBow)
   {
		BONG(0.7, -1.5, 0.2, 90, 0.1, 0.5, txt_SOCKS);
		BONG(0.7, -1, 0.2, 90, 0.1, 0.6, txt_SOCKS);
		BONG(0.7, -0.5, 0.2, 90, 0.1, 0.7, txt_SOCKS); 
		BONG(0.7, 0, 0.2, 90, 0.1, 0.9, txt_SOCKS); 
		BONG(0.7, 0.5, 0.2, 90, 0.1, 0.8, txt_SOCKS); 
		BONG(0.7, 1, 0.2, 90, 0.1, 0.7, txt_SOCKS);    
		BONG(0.7, 1.5, 0.2, 90, 0.1, 0.6, txt_SOCKS); 
   }
 
 
   glColor3f(1,1,1); //Axes

   if (chook)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(chook_len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,chook_len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,chook_len);
      glEnd();
      //For Axes
      glRasterPos3d(chook_len,0.0,0.0);
      characprint("X");
      glRasterPos3d(0.0,chook_len,0.0);
      characprint("Y");
      glRasterPos3d(0.0,0.0,chook_len);
      characprint("Z");
   }
   
   glWindowPos2i(5,5);
   characprint("Angle=%d,%d  Dim=%.1f FOV=%d Projection=%s Light=%s Texture=%",circangle,elevat,worldsize,perspective_view,orth_per_fp_view?"Perpective":"Orthogonal",LIGHT?"On":"Off"); 

   if (LIGHT) 
   { 
      glWindowPos2i(5,45); 
      characprint("Model=%s LocalViewer=%s Distance=%d Elevation=%.1f",sm_flat_shading?"Smooth":"Flat",LocalVIEWER_M?"On":"Off",DofLight,Light_elevat); 
      glWindowPos2i(5,25); 
      characprint("Ambient=%d  Diffuse=%d Specular=%d Emission=%d Shininess=%.0f",AMB,diffuse,SPEC,EMIS,SHIN_Y); 
   } 
   
   CheckError("display"); 
   
   
   glFlush();
   glutSwapBuffers();
}

//Hotkeys for Arrows
void special_hotkey(int hotkey_press,int hotkey_x,int hotkey_y)
{
	
   if (hotkey_press == GLUT_KEY_RIGHT)
   {
      circangle += 5;
   }
   else if (hotkey_press == GLUT_KEY_LEFT)
   {
      circangle -= 5;
   }
   else if (hotkey_press == GLUT_KEY_UP)
   {
      elevat += 5;
   }
   else if (hotkey_press == GLUT_KEY_DOWN)
   {
      elevat -= 5;
   }
   else if (hotkey_press == GLUT_KEY_PAGE_DOWN)
   {
      worldsize += 0.1; 
   }
   else if (hotkey_press == GLUT_KEY_PAGE_UP && worldsize>1)
   {
      worldsize -= 0.1; 
   }
   else if (hotkey_press == GLUT_KEY_F1) 
   {
      sm_flat_shading = 1-sm_flat_shading; 
   }
   else if (hotkey_press == GLUT_KEY_F2) 
   {
      LocalVIEWER_M = 1-LocalVIEWER_M; 
   }
   else if (hotkey_press == GLUT_KEY_F3) 
   {
      DofLight = (DofLight==1) ? 5 : 1; 
   }
   else if (hotkey_press == GLUT_KEY_F8) 
   {
      BallInc = (BallInc==10)?3:10; 
   }
   else if (hotkey_press == GLUT_KEY_F9) 
   {
      UV = -UV; 
   }
  
   circangle %= 360; 
   elevat %= 360; 
   glutPostRedisplay();
}

void idle()
{

   double idle_time = glutGet(GLUT_ELAPSED_TIME)/1000.0; 
   ROT = fmod(90*idle_time,360); 
   glutPostRedisplay();
}

void hotkey_press(unsigned char ch,int hk_press_x,int hk_press_y)
{
   if (ch == 27)
   {
      exit(0);
   }
   else if (ch == '0')
   {
      circangle = elevat = 0;
   }
   else if (ch == 'x' || ch == 'X') 
   {
	  chook = 1-chook; 
   }
   else if (ch == 'l' || ch == 'L') 
   {
      LIGHT = 1-LIGHT; 
   }
   else if (ch == 't') 
   {
      TXTURE_MODE = 1-TXTURE_MODE; 
   }
   else if (ch == 'T') 
   {
      YO_TXTURE = 1-YO_TXTURE; 
   }
   
   else if (ch=='s' && SHINE_L>-1) 
   {
      SHINE_L -= 1; 
   }
   else if (ch=='S' && SHINE_L<7) 
   {
      SHINE_L += 1; 
   }
   else if (ch == 'm' || ch == 'M')
   {
      orth_per_fp_view = 1-orth_per_fp_view;
   }
   else if (ch == 'z' || ch == 'Z') 
   {
      MovOfLight = 1-MovOfLight; 
   }
   else if (ch == '<') 
   {
      ROT += 1;
   }
   else if (ch == '>') 
   {
      ROT -= 1;
   }
   else if (ch == '-' && ch>1) 
   {
	  perspective_view--; 
   }
   else if (ch == '+' && ch<179) 
   {
	  perspective_view++; 
   }
   else if (ch=='[') 
   {
      Light_elevat -= 0.1; 
   }
   else if (ch==']') 
   {
      Light_elevat += 0.1;
   }	  
   else if (ch == '/') 
   {
      DofLight -= 0.1; 
   }
   else if (ch == '*') 
   {
      DofLight += 0.1; 
   }
   else if (ch == 'p' || ch == 'P')
   {
      YOpower_ranger = 1-YOpower_ranger;
   }
   else if (ch == 'b' || ch == 'B')
   {
      RainBow = 1-RainBow;
   }
   else if (ch=='q' && AMB>0) 
   {
      AMB -= 5;
   }
   else if (ch=='Q' && AMB<100) 
   {
      AMB += 5; 
   }
   else if (ch=='w' && diffuse>0) 
   {
      diffuse -= 5;
   }
   else if (ch=='W' && diffuse<100) 
   {
      diffuse += 5; 
   }
   else if (ch=='r' && SPEC>0) 
   {
      SPEC -= 5; 
   }
   else if (ch=='R' && SPEC<100) 
   {
      SPEC += 5; 
   }
   else if (ch=='e' && EMIS>0) 
   {
      EMIS -= 5; 
   }
   else if (ch=='E' && EMIS<100) 
   {
      EMIS += 5; 
   }
   else if (ch=='O') 
   {
      REPETITION += 0.1; 
   }
   else if (ch=='o') 
   {
      REPETITION -= 0.1; 
   }
   if (REPETITION<1) 
   {
	   REPETITION = 1; 
   }

   SHIN_Y = SHINE_L<0 ? 0 : pow(2.0,SHINE_L); 
   PROJECTION(orth_per_fp_view?perspective_view:0,widnheight_ratio,worldsize); 
   glutIdleFunc(MovOfLight?idle:NULL); 
   glutPostRedisplay();
}

//Reshape
void shapeRedraw(int width,int height)
{
   const double worldsize=2.5;
   widnheight_ratio = (height>0) ? (double)width/height : 1; 

   double widnheight = (height>0) ? (double)width/height : 1;
   glViewport(0,0, width,height);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(-widnheight*worldsize,+widnheight*worldsize, -worldsize,+worldsize, -worldsize,+worldsize); 
   
   
   glMatrixMode(GL_MODELVIEW);
   PROJECTION(orth_per_fp_view?perspective_view:0,widnheight_ratio,worldsize); 
   glLoadIdentity();
}




// Tell GLUT what to do
int main(int argument1,char* argument2[])
{
   glutInit(&argument1,argument2);
   glutInitWindowSize(1060,850);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutCreateWindow("Junwoo Jang - CSCI5229 - HW6, PowerRangers with Cylinder(Textured,Light,TwoViewModes)");
   glutIdleFunc(idle);
   #ifdef USEGLEW
   if (glewInit()!=GLEW_OK) Fatal4gl("Error initializing GLEW\n");
   #endif
   glutDisplayFunc(draw_scene);
   glutReshapeFunc(shapeRedraw);
   glutSpecialFunc(special_hotkey);
   glutKeyboardFunc(hotkey_press);
   
   CheckError("init");   
   glutMainLoop();
   return 0;
}
